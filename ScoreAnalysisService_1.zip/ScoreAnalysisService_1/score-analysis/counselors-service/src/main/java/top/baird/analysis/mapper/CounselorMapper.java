package top.baird.analysis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.baird.analysis.po.Counselor;

public interface CounselorMapper extends BaseMapper<Counselor> {
}
