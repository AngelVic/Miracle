package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.baird.analysis.model.Result;
import top.baird.analysis.service.auth.AccountService;
import top.baird.analysis.service.auth.AdminService;
import top.baird.analysis.service.classes.GradeService;
import top.baird.analysis.service.counselors.CounselorService;
import top.baird.analysis.vo.CounselorVO;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Validated
@RestController
@RequestMapping("/counselor")
public class CounselorController {

    @Resource
    CounselorService counselorService;

    @Resource
    AccountService accountService;

    @Resource
    AdminService adminService;

    @GetMapping("/list")
    @ApiOperation(value = "查询负责人列表",tags = "管理员-负责人管理")
    public Result<List<CounselorVO>> getCounselorVOList(@ApiParam("年级Id") Integer gradeId,@ApiParam("关键字")String key){
        return Result.success(counselorService.findListByGradeId(gradeId,key)
                .stream()
                .map(c -> new CounselorVO(
                        c.getAccount(),
                        c.getName(),
                        c.getGradeId(),
                        c.getCreateTime()
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/name")
    @ApiOperation(value = "返回辅导员/管理员姓名",tags = "登录")
    public Result<String> getName(@ApiParam("账号")Integer account){
        String counselorName=accountService.findCounselorName(account).orElse("xxx");
        if (counselorName.equals("xxx")){
            return Result.success(adminService.findAdminName(account).orElse("xxx"));
        }
        return Result.success(counselorName);
    }


}
