package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

import java.time.Instant;

@ApiModel
@AllArgsConstructor
public class FileVO {

    @ApiModelProperty("文件id")
    public final Integer fileId;

    @ApiModelProperty("年级")
    public final Integer grade;

    @ApiModelProperty("专业名")
    public final String majorName;

    @ApiModelProperty("学期")
    public final Integer term;

    @ApiModelProperty("负责人名")
    public final String admin;

    @ApiModelProperty("文件url")
    public final String fileUrl;

    @ApiModelProperty("文件名")
    public final String fileName;

    @ApiModelProperty("上传时间")
    public final Instant uploadTime;

    @ApiModelProperty(value = "状态",notes = "0-处理中;1-已上传;2-已删除")
    public final Integer state;

}
