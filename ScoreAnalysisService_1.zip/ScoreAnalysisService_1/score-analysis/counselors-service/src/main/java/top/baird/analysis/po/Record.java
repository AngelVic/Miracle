package top.baird.analysis.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.Instant;

@Data
public class Record {
    @TableId(type = IdType.AUTO)
    private Integer recordId;
    private Integer account;
    private Boolean isRead;
    private Integer term;
    private Instant createTime;
}
