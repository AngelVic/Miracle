package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

import java.time.Instant;
import java.util.List;

@ApiModel
@AllArgsConstructor
public class RecordVO {

    @ApiModelProperty("预警id")
    public final Integer recordId;

    @ApiModelProperty("已读or未读")
    public final Boolean isRead;

    @ApiModelProperty("创建时间")
    public final Instant creatTime;

    @ApiModelProperty("学期")
    public final Integer term;

    @ApiModelProperty("预警列表")
    public final List<WarningVO> warningList;

}
