package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import top.baird.analysis.ex.CustomParamException;
import top.baird.analysis.model.Result;
import top.baird.analysis.model.dto.FileDTO;
import top.baird.analysis.service.auth.AccountService;
import top.baird.analysis.service.classes.GradeService;
import top.baird.analysis.service.file.FileService;
import top.baird.analysis.service.gpa.ScoreService;
import top.baird.analysis.util.FileUtil;
import top.baird.analysis.vo.FileVO;

import javax.annotation.Resource;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Validated
@RestController
@RequestMapping("/file")
public class FileController {

    @Resource
    AccountService accountService;

    @Resource
    GradeService gradeService;

    @Resource
    FileService fileService;

    @Resource
    ScoreService scoreService;

    @PostMapping(value = "/excel")
    @ApiOperation(value = "上传excel文件",tags = "辅导员-文件管理")
    public Result<Integer> uploadExcel(MultipartFile file,@ApiParam("辅导员账号") Integer account, @ApiParam("年级Id")Integer gradeId) throws Exception {
        if (file.isEmpty()) {
            throw CustomParamException.of("上传文件为空");
        }
        if (!gradeService.exists(gradeId)){
            throw CustomParamException.of("年级专业 {} 不存在", gradeId);
        }
        InputStream inputStream = file.getInputStream();
        String module = "analysis";
        String url = fileService.uploadFileAvatar(inputStream, module, file.getOriginalFilename(),file.getContentType());

        FileDTO fileDTO=new FileDTO(){
            {
                setAccount(account);
                setUrl(url);
                setGradeId(gradeId);
                setFileName(file.getOriginalFilename());
            }
        };
        InputStream inputStream2 = file.getInputStream();
        Integer fileId=fileService.insertFile(fileDTO).orElse(0);
        List<List<Object>> list = FileUtil.parseExcel(inputStream2,file.getOriginalFilename());
        Integer term=fileService.handling(list,fileId,gradeId).orElse(0);
        fileDTO.setTerm(term);
        fileDTO.setId(fileId);
        //因为改了，所以变怪了
        fileService.insertFile(fileDTO);
        inputStream.close();
        return Result.success(term);
    }

    @GetMapping
    @ApiOperation(value = "获取文件列表",tags = "辅导员-文件管理")
    public Result<List<FileVO>> getFileList(@ApiParam("账号")Integer account,@ApiParam("年级Id")Integer gradeId,@ApiParam("学期")Integer term){
        if(!fileService.existTerm(term)){
            throw CustomParamException.of("学期 {} 相关文件不存在", term);
        }
        if(!fileService.existAccount(account)){
            throw CustomParamException.of("账号 {} 相关文件不存在", account);
        }
        return Result.success(fileService.findList(account,gradeId,term)
                .stream()
                .map(fd -> new FileVO(
                        fd.getFileId(),
                        fd.getGrade(),
                        fd.getMajorName(),
                        fd.getTerm(),
                        fd.getAdmin(),
                        fd.getFileUrl(),
                        fd.getFileName(),
                        fd.getUploadTime(),
                        fd.getState()))
                .collect(Collectors.toList())
        );
    }

    @DeleteMapping
    @ApiOperation(value = "批量删除文件",tags = "辅导员-文件管理")
    public Result<Void> deleteFiles(@RequestBody @ApiParam("文件id列表") List<Integer> fileIdList){
        if (fileIdList.isEmpty()){
            throw CustomParamException.of("文件id列表为空", 0);
        }
        scoreService.deleteFiles(fileIdList);
        fileService.deleteFiles(fileIdList);
        return Result.success(null);
    }

}
