package top.baird.analysis.service.impl;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.ObjectMetadata;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.FileMapper;
import top.baird.analysis.model.dto.*;
import top.baird.analysis.model.pojo.FileDetail;
import top.baird.analysis.po.Counselor;
import top.baird.analysis.po.File;
import top.baird.analysis.service.auth.AccountService;
import top.baird.analysis.service.auth.AdminService;
import top.baird.analysis.service.classes.GradeService;
import top.baird.analysis.service.file.FileService;
import top.baird.analysis.service.gpa.CourseService;
import top.baird.analysis.service.gpa.ScoreService;
import top.baird.analysis.service.student.StudentService;

import javax.annotation.Resource;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class FileServiceImpl implements FileService {

    @Value("${aliyun.oss.file.endpoint}")
    private  String endpoints;

    @Value("${aliyun.oss.file.keyid}")
    private  String keyid;

    @Value("${aliyun.oss.file.keysecret}")
    private  String keysecret;

    @Value("${aliyun.oss.file.bucketname}")
    private  String bucketname;

    @Resource
    FileMapper fileMapper;

    @Resource
    StudentService studentService;

    @Resource
    CourseService courseService;

    @Resource
    ScoreService scoreService;

    @Resource
    GradeService gradeService;

    @Resource
    AdminService adminService;

    @Resource
    AccountService accountService;

    @Override
    public void deleteFiles(List<Integer> fileIdList){
        //TODO 删除oss里的内容
        fileMapper.update(null,
                Wrappers.lambdaUpdate(File.class)
                        .in(File::getId,fileIdList)
                        .set(File::getState,2)
        );
    }

    @Override
    public boolean existTerm(Integer term){
        return term != null &&
                fileMapper.selectCount(Wrappers.lambdaQuery(File.class)
                        .eq(File::getTerm, term)
                ) > 0;
    }

    @Override
    public boolean existAccount(Integer account){
        return account != null &&
                fileMapper.selectCount(Wrappers.lambdaQuery(File.class)
                        .eq(File::getAccount, account)
                ) > 0;
    }

    @Override
    public String uploadFileAvatar(InputStream inputStream, String module, String originalFilename, String type) {

        String endpoint = endpoints;
        String accessKeyId = keyid;
        String accessKeySecret = keysecret;
        String bucketName = bucketname;

        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
        String folder = new DateTime().toString("yyyy/MM/dd");
        String fileName = UUID.randomUUID().toString();

        String fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
        String objectName = module + "/" + folder + "/" + fileName + fileExtension;
        ObjectMetadata objectMetadata = new ObjectMetadata();
        objectMetadata.setContentType(type);

        ossClient.putObject(bucketName, objectName, inputStream,objectMetadata);
        ossClient.shutdown();

        return "http://"+bucketName+"."+endpoint+"/"+objectName;

    }

    @Override
    public Optional<Integer> insertFile(FileDTO fileDTO){
        File file=new File(){
            {
                setAccount(fileDTO.getAccount());
                setGradeId(fileDTO.getGradeId());
                setTerm(fileDTO.getTerm());
                setUrl(fileDTO.getUrl());
                setFileName(fileDTO.getFileName());
            }
        };
        if (fileDTO.getId()!=null){
            file.setId(fileDTO.getId());
            file.setState(1);
            fileMapper.update(file,Wrappers.lambdaUpdate(File.class).eq(File::getId,fileDTO.getId()));
        }else {
            fileMapper.insert(file);
        }
        return Optional.ofNullable(file.getId());

    }

    @Override
    public Optional<Integer> handling(List<List<Object>> list, Integer fileId,Integer gradeId){
        List<List<Object>> student=new ArrayList<>();
        for (List<Object> objects : list) {
            List<Object> element = new ArrayList<>();
            element.add(objects.get(1));
            element.add(objects.get(2));
            student.add(element);
        }
        studentService.insertList(student,gradeId);
        List<List<Object>> course=new ArrayList<>();
        for (List<Object> objects : list) {
            List<Object> element = new ArrayList<>();
            element.add(objects.get(3));
            element.add(objects.get(4));
            element.add(objects.get(8));
            course.add(element);
        }
        courseService.insertList(course);
        List<List<Object>> score=new ArrayList<>();
        for (List<Object> objects : list) {
            List<Object> element = new ArrayList<>();
            element.add(objects.get(0));
            element.add(objects.get(1));
            element.add(objects.get(3));
            element.add(objects.get(5));
            element.add(objects.get(6));
            element.add(objects.get(7));
            score.add(element);
        }
        scoreService.insertList(score,fileId);
        Integer term=Integer.parseInt(list.get(0).get(0).toString());
        fileMapper.update(null, Wrappers.lambdaUpdate(File.class)
                        .eq(File::getId,fileId)
                .set(File::getState,1));
        return Optional.ofNullable(term);
    }

    @Override
    public List<FileDetail> findList(Integer account,Integer gradeId,Integer term){
        List<FileDTO> fileDTOS=fileMapper.selectList(Wrappers.lambdaQuery(File.class)
                .eq(File::getAccount,account)
                .eq(File::getGradeId,gradeId)
                .eq(File::getTerm,term)
        )
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
        List<FileDetail> result=new ArrayList<>();
        for (int i=0;i<fileDTOS.size();i++){
            FileDTO fileDTO=fileDTOS.get(i);
            GradeDTO gradeDTO=gradeService.findById(fileDTO.getGradeId()).orElse(null);
            assert gradeDTO != null;
            String adminName=accountService.findCounselorName(account).orElse(" ");
            if (adminName.equals("xxx")){
                adminName=adminService.findAdminName(account).orElse("");
            }
            result.add(new FileDetail(
                    fileDTO.getId(),
                    gradeDTO.getGrade(),
                    gradeDTO.getMajorName(),
                    fileDTO.getTerm(),
                    adminName,
                    fileDTO.getUrl(),
                    fileDTO.getFileName(),
                    fileDTO.getCreateTime(),
                    fileDTO.getState())
            );
        }
        return result;
    }

    @Override
    public List<Integer> findIdList(Integer account){
        return fileMapper.selectList(Wrappers.lambdaQuery(File.class)
                .eq(File::getAccount,account))
                .stream()
                .map(File::getId)
                .collect(Collectors.toList());
    }

    private FileDTO toDTO(File file) {
        FileDTO f = new FileDTO();
        f.setId(file.getId());
        f.setAccount(file.getAccount());
        f.setCreateTime(file.getCreateTime());
        f.setGradeId(file.getGradeId());
        f.setTerm(file.getTerm());
        f.setState(file.getState());
        f.setFileName(file.getFileName());
        f.setUrl(file.getUrl());
        return f;
    }

}
