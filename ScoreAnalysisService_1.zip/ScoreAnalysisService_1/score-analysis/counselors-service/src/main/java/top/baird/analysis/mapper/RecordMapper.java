package top.baird.analysis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.baird.analysis.po.Record;

public interface RecordMapper extends BaseMapper<Record> {
}
