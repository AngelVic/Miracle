package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

import java.time.Instant;

@ApiModel
@AllArgsConstructor
public class CounselorVO {

    @ApiModelProperty("辅导员账号")
    public final Integer account;

    @ApiModelProperty("辅导员昵称")
    public final String name;

    @ApiModelProperty("年级专业id")
    public final Integer gradeId;

    @ApiModelProperty("创建时间")
    public final Instant createTime;

}
