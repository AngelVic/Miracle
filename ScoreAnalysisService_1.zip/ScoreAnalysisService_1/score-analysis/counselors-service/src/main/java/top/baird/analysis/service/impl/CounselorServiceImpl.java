package top.baird.analysis.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.CounselorMapper;
import top.baird.analysis.model.dto.AccountDTO;
import top.baird.analysis.model.dto.CounselorDTO;
import top.baird.analysis.po.Counselor;
import top.baird.analysis.service.auth.AccountService;
import top.baird.analysis.service.counselors.CounselorService;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CounselorServiceImpl implements CounselorService {

    @Resource
    CounselorMapper counselorMapper;

    @Resource
    AccountService accountService;

    @Override
    public void insert(CounselorDTO counselorDTO){
        if (counselorDTO.getGradeId()!=null){
            Counselor counselor=new Counselor(){
                {
                    setAccount(counselorDTO.getAccount());
                    setGradeId(counselorDTO.getGradeId());
                }
            };
            counselorMapper.insert(counselor);
        }
    }

    @Override
    public void delete(Integer account){
        counselorMapper.delete(Wrappers.lambdaQuery(Counselor.class).eq(Counselor::getAccount,account));
    }

    @Override
    public void update(Integer account,List<Integer> gradeIdList){
        if (accountService.exists(account)){
            counselorMapper.delete(Wrappers.lambdaQuery(Counselor.class).eq(Counselor::getAccount,account));
            for (int gradeId:gradeIdList) {
                counselorMapper.insert(new Counselor(){{
                    setAccount(account);
                    setGradeId(gradeId);
                }});
            }
        }
    }

    @Override
    public List<Integer> findGradeIdByAccount(Integer account){
        return counselorMapper.selectList(Wrappers.lambdaQuery(Counselor.class)
                .eq(Counselor::getAccount,account)
                .select(Counselor::getGradeId)
        )
                .stream()
                .map(Counselor::getGradeId)
                .collect(Collectors.toList());
    }

    @Override
    public List<CounselorDTO> findListByGradeId(Integer gradeId,String key){
        List<Integer> accountList=accountService.findListByKey(key);
        return counselorMapper.selectList(Wrappers.lambdaQuery(Counselor.class)
                .eq(Counselor::getGradeId,gradeId)
                .in(Counselor::getAccount,accountList)
        )
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    private CounselorDTO toDTO(Counselor counselor) {
        CounselorDTO s = new CounselorDTO();
        s.setAccount(counselor.getAccount());
        s.setGradeId(counselor.getGradeId());
        s.setId(counselor.getId());
        AccountDTO accountDTO=accountService.findById(s.getAccount()).orElse(null);
        s.setName(accountDTO.getName());
        s.setCreateTime(accountDTO.getCreateTime());
        return s;
    }

}
