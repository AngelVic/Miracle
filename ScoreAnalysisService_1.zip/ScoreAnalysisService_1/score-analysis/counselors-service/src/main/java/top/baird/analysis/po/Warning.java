package top.baird.analysis.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

@Data
public class Warning {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private Integer studentId;
    private Integer recordId;
    private Integer failNum;
    private Integer room;
    private Integer building;
}
