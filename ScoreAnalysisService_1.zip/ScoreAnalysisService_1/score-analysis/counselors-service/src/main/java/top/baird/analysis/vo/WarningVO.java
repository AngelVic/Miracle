package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

import java.time.Instant;

@ApiModel
@AllArgsConstructor
public class WarningVO {

    @ApiModelProperty("学号")
    public final Integer studentId;

    @ApiModelProperty("学生姓名")
    public final String studentName;

    @ApiModelProperty("挂科数")
    public final Integer failNum;

    @ApiModelProperty(value = "宿舍楼",notes = "如果为空就为个人型预警")
    public final Integer building;

    @ApiModelProperty(value = "宿舍号",notes = "如果为空就为个人型预警")
    public final Integer room;

}
