package top.baird.analysis.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.RecordMapper;
import top.baird.analysis.mapper.WarningMapper;
import top.baird.analysis.model.dto.*;
import top.baird.analysis.po.Record;
import top.baird.analysis.po.Warning;
import top.baird.analysis.service.counselors.CounselorService;
import top.baird.analysis.service.counselors.WarningService;
import top.baird.analysis.service.gpa.QuotaService;
import top.baird.analysis.service.gpa.ScoreService;
import top.baird.analysis.service.student.StudentService;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class WarningServiceImpl implements WarningService {

    @Resource
    WarningMapper warningMapper;

    @Resource
    RecordMapper recordMapper;

    @Resource
    ScoreService scoreService;

    @Resource
    CounselorService counselorService;

    @Resource
    StudentService studentService;

    @Resource
    QuotaService quotaService;

    @Override
    public void createWarning(Integer account,Integer term){
        List<Integer> gradeIdList=counselorService.findGradeIdByAccount(account);
        QuotaDTO quota=quotaService.findQuota(account);
        List<ScoreDTO> totalList=new ArrayList<>();
        for (Integer i : gradeIdList) {
            List<ScoreDTO> scoreList = scoreService.findListByGradeIdAndTerm(i, term);
            totalList.addAll(scoreList);
        }
        List<Integer> studentSet= totalList.stream().map(ScoreDTO::getStudentId).distinct().collect(Collectors.toList());
        //创建新记录
        Record record=new Record(){
            {
                setAccount(account);
                setTerm(term);
            }
        };

        recordMapper.insert(record);
        boolean create=false;
        //查找挂科学生
        List<Integer> failStudent=new LinkedList<>();

        for (Integer s : studentSet){
            Double pass=quota.getCutOff();
            Double sPass=quota.getSpecialCutoff();
            int count;
            if (studentService.findIsSpecial(s)){
                count= (int) totalList.stream()
                        .filter(scoreDTO -> scoreDTO.getStudentId().equals(s))
                        .map(ScoreDTO::getScore)
                        .filter(d -> d < sPass).count();
            }else {
                count= (int) totalList.stream()
                        .filter(scoreDTO -> scoreDTO.getStudentId().equals(s))
                        .map(ScoreDTO::getScore)
                        .filter(d->d<pass).count();
            }
            if (count!=0){
                failStudent.add(s);
            }
            if (count>=2){
                create=true;
                warningMapper.insert(new Warning(){
                    {   setStudentId(s);
                        setFailNum(count);
                        setRecordId(record.getRecordId());
                    }
                });
            }
        }

        //创建宿舍型预警
        createRoomWarning(failStudent,term,account);
        //如果没有预警则不创建
        if (!create){
            recordMapper.deleteById(record.getRecordId());
        }

    }


    private void createRoomWarning(List<Integer> studentIdList,Integer term,Integer account){
        List<StudentDTO> studentList=studentService
                .findStudentListByIds(studentIdList)
                .stream()
                .filter(studentDTO -> studentDTO.getBuilding()!=0 && studentDTO.getRoom()!=0)
                .collect(Collectors.toList());
        Record record=new Record(){
            {
                setAccount(account);
                setTerm(term);
            }
        };

        boolean create=false;
        for (int i=0;i<studentList.size();i++){
            StudentDTO student=studentList.get(i);
            long count=studentList
                    .stream()
                    .filter(s -> s.getRoom().equals(student.getRoom())&&s.getBuilding().equals(student.getBuilding()))
                    .count();
            if (count>=2){
                create=true;
                warningMapper.insert(new Warning(){
                    {
                        setStudentId(student.getStudentId());
                        setRecordId(record.getRecordId());
                        setRoom(student.getRoom());
                        setBuilding(student.getBuilding());
                    }
                });
            }
        }
        if (!create){
            recordMapper.deleteById(record.getRecordId());
        }
    }

    @Override
    public List<RecordDTO> getListByAccountAndIsRead(Integer account,Boolean isRead){
        return recordMapper.selectList(Wrappers.lambdaQuery(Record.class)
                .eq(Record::getAccount,account)
                .eq(Record::getIsRead,isRead))
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void allIsRead(Integer account){
        recordMapper.update(null,
                Wrappers.lambdaUpdate(Record.class)
                        .eq(Record::getAccount,account)
                        .set(Record::getIsRead,true)
        );
    }

    @Override
    public void isRead(Integer recordId){
        recordMapper.update(null,
                Wrappers.lambdaUpdate(Record.class)
                        .eq(Record::getRecordId,recordId)
                        .set(Record::getIsRead,true));
    }

    private List<WarningDTO> findList(Integer recordId){
        return warningMapper.selectList(Wrappers.lambdaQuery(Warning.class)
                .eq(Warning::getRecordId,recordId))
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    private WarningDTO toDTO(Warning warning) {
        WarningDTO w = new WarningDTO();
        w.setId(warning.getId());
        w.setFailNum(warning.getFailNum());
        w.setRecordId(warning.getRecordId());
        w.setStudentId(warning.getStudentId());
        w.setStudentName(studentService.findNameById(w.getStudentId()).orElse(""));
        w.setBuilding(warning.getBuilding());
        w.setRoom(warning.getRoom());
        return w;
    }

    private RecordDTO toDTO(Record record) {
        RecordDTO r = new RecordDTO();
        r.setAccount(record.getAccount());
        r.setCreateTime(record.getCreateTime());
        r.setTerm(record.getTerm());
        r.setIsRead(record.getIsRead());
        r.setRecordId(record.getRecordId());
        r.setWarningList(findList(r.getRecordId()));
        return r;
    }

}
