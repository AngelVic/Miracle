package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.baird.analysis.model.Result;
import top.baird.analysis.service.counselors.WarningService;
import top.baird.analysis.vo.RecordVO;
import top.baird.analysis.vo.WarningVO;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Validated
@RestController
@RequestMapping("/warning")
public class WarningController {

    @Resource
    WarningService warningService;

    @PostMapping
    @ApiOperation(value = "检索数据库创建新预警",tags = "辅导员-成绩预警",notes = "这个可以默认设置在上传文件后？也可以做刷新用，不知道有没有需要所以先独立出来")
    public Result<Void> createWarning(@ApiParam("账号") Integer account,@ApiParam("学期")Integer term){
        warningService.createWarning(account,term);
        return Result.success(null);
    }

    @GetMapping
    @ApiOperation(value = "获取预警列表",tags = "辅导员-成绩预警")
    public Result<List<RecordVO>> getRecord(@ApiParam("账号")Integer account, @ApiParam("已读")Boolean isRead){
        return Result.success(warningService.getListByAccountAndIsRead(account,isRead)
                .stream()
                .map(rd -> new RecordVO(
                        rd.getRecordId(),
                        rd.getIsRead(),
                        rd.getCreateTime(),
                        rd.getTerm(),
                        rd.getWarningList()
                                .stream()
                                .map(wd -> new WarningVO(
                                        wd.getStudentId(),
                                        wd.getStudentName(),
                                        wd.getFailNum(),
                                        wd.getBuilding(),
                                        wd.getRoom()))
                                .collect(Collectors.toList())
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/total")
    @ApiOperation(value = "全部已读",tags = "辅导员-成绩预警")
    public Result<Void> allIsRead(@ApiParam("账号")Integer account){
        warningService.allIsRead(account);
        return Result.success(null);
    }

    @GetMapping("/read")
    @ApiOperation(value = "单条预警已读",tags = "辅导员-成绩预警")
    public Result<Void> isRead(@ApiParam("预警id")Integer recordId){
        warningService.isRead(recordId);
        return Result.success(null);
    }

}
