package top.baird.analysis.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.List;

@ApiModel
@AllArgsConstructor
public class AccountUpsert {

    @ApiModelProperty(value = "账号", notes = "不为空时为编辑")
    public final Integer account;

    @NotNull
    @ApiModelProperty(value = "辅导员姓名", required = true)
    public final String name;

    @ApiModelProperty(value = "年级id列表")
    public final List<Integer> gradeIdList;

}
