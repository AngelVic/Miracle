package top.baird.analysis.service;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import top.baird.analysis.mapper.AccountMapper;
import top.baird.analysis.model.dto.AccountDTO;
import top.baird.analysis.model.dto.CounselorDTO;
import top.baird.analysis.po.Account;
import top.baird.analysis.service.auth.AccountService;
import top.baird.analysis.service.counselors.CounselorService;
import top.baird.analysis.service.file.FileService;
import top.baird.analysis.service.gpa.QuotaService;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AccountServiceImpl implements AccountService{

    private static final String DEFAULT_PWD = "{noop}123456";

    @Resource
    private AccountMapper accountMapper;

    @Resource
    private CounselorService counselorService;

    @Resource
    private FileService fileService;

    @Resource
    private QuotaService quotaService;

    @Override
    public Optional<AccountDTO> findById(Integer accountId){
        return Optional.ofNullable(accountMapper.selectById(accountId)).map(a -> {
            AccountDTO ad = new AccountDTO();
            ad.setAccountId(a.getAccount());
            ad.setPwd(a.getPassword());
            ad.setName(a.getName());
            ad.setCreateTime(a.getCreateTime());
            return ad;
        });
    }

    @Override
    public boolean exists(Integer account){
        return account != null &&
                accountMapper.selectCount(Wrappers.lambdaQuery(Account.class)
                        .eq(Account::getAccount, account)
                ) > 0;
    }

    @Override
    public Optional<String> findCounselorName(Integer account){
        Account account1=accountMapper.selectById(account);
        if (account1!=null){
            return Optional.of(account1.getName());
        }else return Optional.of("xxx");
    }

    @Override
    @Transactional
    public Optional<Integer> upsert(AccountDTO accountDTO) {
        if (accountDTO.getAccountId() == null) {
            Account account = new Account() {{
                setPassword(DEFAULT_PWD);
                setName(accountDTO.getName());
            }};
            accountMapper.insert(account);
            Integer accountId=account.getAccount();
            quotaService.createDefault(accountId);
            accountDTO.getGradeIdList().forEach(x-> counselorService.insert(new CounselorDTO(){
                {
                    setAccount(accountId);
                    setGradeId(x);
                }
            }));
            return Optional.of(accountId);
        }
        try {
            accountMapper.update(null,Wrappers.lambdaUpdate(Account.class)
                    .eq(Account::getAccount,accountDTO.getAccountId())
                    .set(Account::getName,accountDTO.getName())
            );
            counselorService.update(accountDTO.getAccountId(),accountDTO.getGradeIdList());
            //写完了
            return Optional.of(accountDTO.getAccountId());
        } catch (DuplicateKeyException e) {
            return Optional.empty();
        }
    }

    @Override
    @Transactional
    public void erase(Integer account) {
        if (account == null) {
            return;
        }
        accountMapper.deleteById(account);
        //新加的补充部分
        if (fileService.existAccount(account)){
            fileService.deleteFiles(fileService.findIdList(account));
        }
        counselorService.delete(account);
    }

    @Override
    public void resetPwd(Integer accountId) {
        Account account=accountMapper.selectById(accountId);
        account.setPassword(DEFAULT_PWD);
        accountMapper.updateById(account);
    }

    @Override
    public Optional<Integer> alterPwd(Integer accountId,String oldPwd,String newPwd){
        Account account=accountMapper.selectById(accountId);
        if (oldPwd.matches(account.getPassword().substring(6))){
            accountMapper.updateById(new Account() {{
                setAccount(accountId);
                setPassword("{noop}"+newPwd);
            }});
            return Optional.of(1);
        }else {
            return Optional.of(0);
        }
    }

    @Override
    public List<Integer> findListByKey(String key){
        return accountMapper.selectList(Wrappers.lambdaQuery(Account.class)
                .like(key!=null,Account::getName,key)
                .or()
                .like(key!=null,Account::getAccount,key)
        )
                .stream()
                .map(Account::getAccount)
                .collect(Collectors.toList());
    }


}
