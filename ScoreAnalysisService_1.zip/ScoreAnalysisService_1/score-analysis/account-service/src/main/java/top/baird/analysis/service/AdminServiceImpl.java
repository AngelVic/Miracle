package top.baird.analysis.service;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.AdminMapper;
import top.baird.analysis.model.dto.AdminDTO;
import top.baird.analysis.po.Account;
import top.baird.analysis.po.Admin;
import top.baird.analysis.service.auth.AdminService;

import javax.annotation.Resource;
import java.util.Optional;

@Service
public class AdminServiceImpl implements AdminService {

    @Resource
    private AdminMapper adminMapper;

    @Override
    public Optional<AdminDTO> findById(Integer accountId){
        return Optional.ofNullable(adminMapper.selectById(accountId)).map(a -> {
            AdminDTO ad = new AdminDTO();
            ad.setAccountId(a.getAccount());
            ad.setPwd(a.getPassword());
            return ad;
        });
    }

    @Override
    public boolean exists(Integer account){
        return account != null &&
                adminMapper.selectCount(Wrappers.lambdaQuery(Admin.class)
                        .eq(Admin::getAccount, account)
                ) > 0;
    }

    @Override
    public Optional<Integer> alterPwd(Integer accountId,String oldPwd,String newPwd){
        Admin admin=adminMapper.selectById(accountId);
        if (oldPwd.matches(admin.getPassword().substring(6))){
            adminMapper.updateById(new Admin() {{
                setAccount(accountId);
                setPassword("{noop}"+newPwd);
            }});
            return Optional.of(1);
        }else {
            return Optional.of(0);
        }
    }

    @Override
    public Optional<String> findAdminName(Integer account){
        return Optional.of(adminMapper.selectById(account).getName());
    }

    @Override
    public Optional<Integer> findCollegeByAccount(Integer account){
        return Optional.of(adminMapper.selectById(account).getCollegeId());
    }

}
