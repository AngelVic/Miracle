package top.baird.analysis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.baird.analysis.po.Admin;

public interface AdminMapper extends BaseMapper<Admin> {
}
