package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.baird.analysis.ex.CustomParamException;
import top.baird.analysis.model.Result;
import top.baird.analysis.service.auth.AdminService;

import javax.annotation.Resource;

@Validated
@RestController
@RequestMapping("/admin")
public class AdminController {

    @Resource
    AdminService adminService;

    @PutMapping("/alter")
    @ApiOperation(value = "修改管理员密码",tags = "???")
    public Result<Integer> alterPwd(Integer account, String oldPwd, String newPwd){
        if (!adminService.exists(account)){
            throw CustomParamException.of("账号 {} 不存在", account);
        }
        return Result.success(adminService.alterPwd(account,oldPwd,newPwd).orElse(0));
    }
}
