package top.baird.analysis.service;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import top.baird.analysis.model.dto.AccountDTO;
import top.baird.analysis.model.dto.AdminDTO;
import top.baird.analysis.service.auth.AccountService;
import top.baird.analysis.service.auth.AdminService;

import javax.annotation.Resource;
import java.util.Optional;


@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Resource
    private AccountService accountService;

    @Resource
    private AdminService adminService;

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {

        AdminDTO adminDTO=adminService.findById(Integer.valueOf(s)).orElse(null);
        AccountDTO accountDTO=accountService.findById(Integer.valueOf(s)).orElse(null);
        if (adminDTO != null){
            return Optional.of(adminDTO.getPwd()).map(
                    password -> User.builder()
                            .username(s)
                            .password(password)
                            .roles("USER", "ADMIN")
                            .build()
            ).orElse(null);
        }else{
            assert accountDTO != null;
            return Optional.of(accountDTO.getPwd()).map(
                    password -> User.builder()
                            .username(s)
                            .password(password)
                            .roles("USER")
                            .build()
            ).orElse(null);
        }
    }

}
