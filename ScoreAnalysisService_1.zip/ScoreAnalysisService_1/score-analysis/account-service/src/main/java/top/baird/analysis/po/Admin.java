package top.baird.analysis.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import top.baird.analysis.model.able.JsonAble;

import java.time.Instant;

@Data
public class Admin implements JsonAble {
    @TableId(type = IdType.AUTO)
    private Integer account;
    private String password;
    private String name;
    private Integer collegeId;
}
