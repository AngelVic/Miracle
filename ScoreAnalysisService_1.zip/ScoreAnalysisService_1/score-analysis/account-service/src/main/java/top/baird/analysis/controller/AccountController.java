package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import top.baird.analysis.ex.CustomParamException;
import top.baird.analysis.model.Result;
import top.baird.analysis.model.dto.AccountDTO;
import top.baird.analysis.req.AccountUpsert;
import top.baird.analysis.service.auth.AccountService;
import top.baird.analysis.service.auth.AdminService;
import top.baird.analysis.service.gpa.QuotaService;
import top.baird.analysis.vo.AccountVO;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

@Validated
@RestController
@RequestMapping("/account")
public class AccountController {

    @Resource
    private AccountService accountService;

    @Resource
    private QuotaService quotaService;

    @PostMapping
//    @Secured("ROLE_ADMIN")
    @ApiOperation(value = "新建|修改辅导员账号",tags = "管理员-负责人管理")
    public Result<Integer> addOrEdit(@RequestBody @Valid AccountUpsert account) {
        if ( account.account!=null&&!accountService.exists(account.account)) {
            throw CustomParamException.of("账号 {} 不存在", account.account);
        }
        if (account.gradeIdList.size()<1){
            throw CustomParamException.of("年级专业列表为空");
        }
        AccountDTO accountDTO=new AccountDTO(){
            {
                setAccountId(account.account);
                setName(account.name);
                setGradeIdList(account.gradeIdList);
            }
        };

        return Result.success(accountService.upsert(accountDTO).orElse(null));
    }

    @PostMapping("/delete")
//    @Secured("ROLE_ADMIN")
    @ApiOperation(value = "删除账号",tags = "管理员-负责人管理")
    public Result<Void> erase(@ApiParam("辅导员账号") Integer account) {
        accountService.erase(account);
        return Result.success(null);
    }

    @PutMapping("/{account}/pwd")
//    @Secured("ROLE_ADMIN")
    @ApiOperation(value = "重置密码",tags = "管理员-负责人管理")
    public Result<Void> resetPwd(@ApiParam("辅导员账号") @PathVariable Integer account) {
        accountService.resetPwd(account);
        return Result.success(null);
    }

    @PutMapping("/alter")
    @ApiOperation(value = "修改辅导员密码",tags = "管理员-负责人管理")
    public Result<Integer> alterPwd(Integer account,String oldPwd,String newPwd){
        if (!accountService.exists(account)){
            throw CustomParamException.of("账号 {} 不存在", account);
        }
        return Result.success(accountService.alterPwd(account,oldPwd,newPwd).orElse(0));
    }


}
