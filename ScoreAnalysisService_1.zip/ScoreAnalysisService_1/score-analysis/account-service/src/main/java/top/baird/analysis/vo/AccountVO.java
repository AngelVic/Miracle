package top.baird.analysis.vo;

public class AccountVO {
}
