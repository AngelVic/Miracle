package top.baird.analysis.config.security.handler;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import top.baird.analysis.model.Result;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


public class HandlerUtil {
    public static void handle(HttpServletResponse response, HttpStatus httpStatus, String msg) throws IOException {
        response.setStatus(httpStatus.value());
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().print(Result.of(httpStatus, msg, null).toJsonString());
    }

    public static void handleAuthentication(HttpServletResponse response, HttpStatus httpStatus, String msg,Authentication authentication) throws IOException {
        response.setStatus(httpStatus.value());
        response.setContentType("application/json;charset=UTF-8");
        int sign=0;
        if (authentication.getAuthorities().size()>1){ sign=1;}
        response.getWriter().print(Result.of(httpStatus, msg,sign).toJsonString());
    }
}