package top.baird.analysis.config;

import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author chenzhimeng
 * @date 2021/10/13
 **/
@Configuration
@ConfigurationPropertiesScan("top.baird.analysis.prop")
public class PropConf {
}
