package top.baird.analysis.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * @author chenzhimeng
 * @date 2021/10/27
 */
@Configuration
public class SwaggerConf {
    @Bean
    Docket getUserDocket() {
        ApiInfo apiInfo = new ApiInfoBuilder()
                .title("成绩分析服务")
                .description("暂时没有东西，之后拿来塞补充")
                .version("1.0.0")
                .contact(new Contact("Baird", "", "xxx.com"))
                .build();
        return new Docket(DocumentationType.OAS_30)
                .apiInfo(apiInfo)
                .select()
                .apis(RequestHandlerSelectors.basePackage("top.baird.analysis.controller"))
                .paths(PathSelectors.any())
                .build();
    }
}