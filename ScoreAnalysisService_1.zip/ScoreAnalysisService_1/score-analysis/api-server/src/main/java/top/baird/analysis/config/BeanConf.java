package top.baird.analysis.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * @author
 * @date 2022/3/7
 */
@Configuration
public class BeanConf {

    Executor threadPool() {
        return Executors.newFixedThreadPool(4);
    }
}

