package top.baird.analysis.handler;

import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import top.baird.analysis.model.Result;

import javax.validation.ConstraintViolationException;

@ResponseBody
@ControllerAdvice
public class ValidationHandler {
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler({MissingServletRequestParameterException.class, ConstraintViolationException.class, MissingServletRequestPartException.class})
    Result<Void> handle400(Exception e) {
        return Result.reject(e.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(BindException.class)
    Result<Void> handle400(BindException e) {
        FieldError fieldError = e.getFieldError();
        assert fieldError != null;
        return Result.reject(fieldError.getField() + " " + fieldError.getDefaultMessage());
    }
}