package top.baird.analysis.handler;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import top.baird.analysis.model.Result;
import top.baird.analysis.ex.CustomParamException;


/**
 * @author chenzhimeng
 * @date 2021/10/27
 */
@ResponseBody
@ControllerAdvice(basePackages = "top.baird.analysis.controller")
public class CustomExceptionHandler {
    @ExceptionHandler(CustomParamException.class)
    public Result<Void> handle400(CustomParamException e) {
        return Result.reject(e.getMessage());
    }
}
