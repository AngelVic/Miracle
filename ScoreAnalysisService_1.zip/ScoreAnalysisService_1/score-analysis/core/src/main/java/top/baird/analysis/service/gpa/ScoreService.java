package top.baird.analysis.service.gpa;

import top.baird.analysis.model.dto.ScoreDTO;
import top.baird.analysis.model.pojo.*;

import java.util.List;
import java.util.Set;

public interface ScoreService {

    void deleteFiles(List<Integer> fileIdList);

    Set<Integer> getCourseIdList(Integer majorId);

    BaseScore findBaseScore(Integer gradeId, Integer term,Integer account);

    Set<Integer> getCounselorCourseIdList(Integer gradeId,Integer term);

    Set<Integer> getClassScoreCourseList(Integer classId,Integer term);

    List<GradeScore> findGradeScoreList(Integer majorId, Integer courseId, Integer account);

    void insertList(List<List<Object>> score,Integer fileId);

    List<TermGrade> findGradeListByStudentIdAndTerm(Integer studentId,Integer term);

    ScoreComparison findScoreComparison(Integer account, Integer term, Integer classId);

    List<ScoreDTO> findListByTermAndClassIdAndCourseId(Integer term,Integer classId,Integer courseId);

    List<ScoreDTO> findListByGradeIdAndTerm(Integer gradeId,Integer term);

    List<ClassScore> getClassScore(Integer classId, Integer term, Set<Integer> courseIdList);

    List<Average> findSubjectAverage(Integer gradeId, Integer term);

    List<Average> getClassAverage(Integer classId, Integer term);

    List<Integer> findPieChart(Double extent,Integer gradeId,Integer term);

    List<Integer> findClassPieChart(Double extent,Integer classId,Integer term);

    List<Integer> findClassRankAndGradeRank(Integer studentId,Integer term);

    List<CounselorScore> findCounselorScoreList(Integer gradeId, Integer term,Integer account,Integer courseId);

}
