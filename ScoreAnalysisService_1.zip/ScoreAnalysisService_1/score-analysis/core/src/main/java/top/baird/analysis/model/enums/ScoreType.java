package top.baird.analysis.model.enums;

public class ScoreType {
}
