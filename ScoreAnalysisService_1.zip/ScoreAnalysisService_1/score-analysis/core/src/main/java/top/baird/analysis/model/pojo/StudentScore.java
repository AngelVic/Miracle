package top.baird.analysis.model.pojo;

import lombok.Data;

@Data
public class StudentScore {
    public Integer classRanking;
    public Integer gradeRanking;
    public Integer gradePoint;
}
