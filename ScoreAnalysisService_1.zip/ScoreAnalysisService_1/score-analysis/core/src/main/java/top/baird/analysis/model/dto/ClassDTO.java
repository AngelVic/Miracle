package top.baird.analysis.model.dto;

import lombok.Data;

@Data
public class ClassDTO {
    private Integer classId;
    private Integer name;
    private Integer gradeId;
    private Integer grade;
    private String major;
}
