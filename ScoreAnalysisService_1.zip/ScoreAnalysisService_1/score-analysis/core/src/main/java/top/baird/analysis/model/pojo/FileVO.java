package top.baird.analysis.model.pojo;

import lombok.Data;

@Data
public class FileVO {
    private Integer term;
    private Integer studentId;
    private String name;
    private String courseName;
    private Double credit;
    private Double score;
    private Double gradePoint;
    private String type;
    private String courseType;
}
