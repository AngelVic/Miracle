package top.baird.analysis.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Average {
    public Integer courseId;
    public String courseName;
    public Double average;
}
