package top.baird.analysis.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import top.baird.analysis.model.able.JsonAble;

import java.time.Instant;
import java.util.List;


@Data
public class AccountDTO  {
    private Integer accountId;
    private String pwd;
    private String name;
    private Instant createTime;
    private List<Integer> gradeIdList;
}
