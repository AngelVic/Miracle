package top.baird.analysis.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CounselorScore {
    private Integer classNum;
    private Integer totalNum;
    private Double gradePointAB;
    private Double average;
    private Integer failNum;
    private Double subjectAB;
    private Double pass;
}
