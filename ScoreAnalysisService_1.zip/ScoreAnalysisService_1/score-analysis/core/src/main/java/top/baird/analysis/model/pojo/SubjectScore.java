package top.baird.analysis.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SubjectScore {
    public Integer courseId;
    public Double score;
    public Double makeUp;
}
