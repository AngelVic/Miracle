package top.baird.analysis.model.dto;

import lombok.Data;
import top.baird.analysis.model.enums.ScoreType;

@Data
public class ScoreDTO {
    private Integer scoreId;
    private Integer studentId;
    private Integer courseId;
    private Integer majorId;
    private Integer gradeId;
    private Integer fileId;
    private Integer classId;
    private Double gradePoint;
    private Double score;
    private String type;
    private Double makeUp;
    private Double credit;
    private Integer term;

    public double getTermGradePoint(){
        return  credit*gradePoint;
    }
}
