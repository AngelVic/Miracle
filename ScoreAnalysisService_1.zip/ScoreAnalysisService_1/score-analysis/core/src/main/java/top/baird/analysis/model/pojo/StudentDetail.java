package top.baird.analysis.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import top.baird.analysis.model.dto.StudentDTO;

import java.util.List;

@Data
@AllArgsConstructor
public class StudentDetail {
    private StudentDTO studentDTO;
    private Integer classRank;
    private Integer gradeRank;
    private List<TermGrade> gradeList;
}
