package top.baird.analysis.model.dto;

import lombok.Data;

@Data
public class CourseDTO {
    private Integer courseId;
    private String name;
    private String type;
    private Double credit;
}
