package top.baird.analysis.service.auth;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import top.baird.analysis.model.Result;
import top.baird.analysis.model.dto.AccountDTO;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface AccountService {

    Optional<AccountDTO> findById(Integer accountId);

    boolean exists(Integer account);

    Optional<Integer> upsert(AccountDTO accountDTO);

    void erase(Integer accountIdList);

    void resetPwd( Integer account);

    Optional<String> findCounselorName(Integer account);

    Optional<Integer> alterPwd(Integer accountId,String oldPwd,String newPwd);

    List<Integer> findListByKey(String key);

}
