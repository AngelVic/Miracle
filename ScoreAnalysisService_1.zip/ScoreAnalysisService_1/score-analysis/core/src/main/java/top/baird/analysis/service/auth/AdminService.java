package top.baird.analysis.service.auth;

import top.baird.analysis.model.dto.AccountDTO;
import top.baird.analysis.model.dto.AdminDTO;

import java.util.Optional;

public interface AdminService {

     Optional<AdminDTO> findById(Integer accountId);

     Optional<String> findAdminName(Integer account);

     Optional<Integer> findCollegeByAccount(Integer account);

     boolean exists(Integer account);

     Optional<Integer> alterPwd(Integer accountId,String oldPwd,String newPwd);
}
