package top.baird.analysis.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import top.baird.analysis.model.dto.GradeDTO;

import java.util.List;

@Data
@AllArgsConstructor
public class CounselorDetail {
    private Integer account;
    private List<GradeDTO> gradeList;
    private String name;
}
