package top.baird.analysis.model.able;

import com.alibaba.fastjson.JSON;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * @author
 * @date 2022/3/7
 **/
public interface JsonAble extends Serializable {
    default String toJsonString() {
        return JSON.toJSONString(this);
    }
}

