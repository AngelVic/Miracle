package top.baird.analysis.service.classes;

import top.baird.analysis.model.dto.ClassDTO;

import java.util.List;
import java.util.Optional;

public interface ClassService {

    boolean exists(Integer classId);

    Optional<Integer> findGradeIdByClassId(Integer classId);

    Optional<Integer> toFindClassId(String value,Integer gradeId);

    List<ClassDTO> findClassListByGradeId(Integer gradeId);

    List<ClassDTO> findClassDetailByAccount(Integer account);

    Optional<Integer> findClassIdByAll(Integer gradeId,Integer classNum);

}
