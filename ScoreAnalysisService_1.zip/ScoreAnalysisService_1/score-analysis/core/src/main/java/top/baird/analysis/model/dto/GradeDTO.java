package top.baird.analysis.model.dto;

import lombok.Data;

@Data
public class GradeDTO {
    private Integer id;
    private Integer grade;
    private Integer majorId;
    private String majorName;
}
