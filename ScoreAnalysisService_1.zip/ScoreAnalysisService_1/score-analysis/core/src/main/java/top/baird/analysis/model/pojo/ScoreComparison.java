package top.baird.analysis.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ScoreComparison {

    public Double gradeAB;

    public Double classAB;

    public Double gradePass;

    public Double classPass;

}
