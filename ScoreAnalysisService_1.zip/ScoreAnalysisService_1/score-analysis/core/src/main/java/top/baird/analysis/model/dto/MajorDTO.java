package top.baird.analysis.model.dto;

import lombok.Data;

@Data
public class MajorDTO {
    private Integer majorId;
    private String name;
    private Integer majorCode;
    private Integer collegeId;
}
