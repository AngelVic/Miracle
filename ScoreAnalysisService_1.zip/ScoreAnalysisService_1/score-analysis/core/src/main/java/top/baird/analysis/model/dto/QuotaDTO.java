package top.baird.analysis.model.dto;

import lombok.Data;

@Data
public class QuotaDTO {
    private Integer quotaId;
    private Double cutOff;
    private Double specialCutoff;
    private Double gradeAB;
    private Double classAB;
    private Double subjectAB;
    private Boolean isAdmin;
}
