package top.baird.analysis.model.dto;

import lombok.Data;

import java.time.Instant;
import java.util.List;

@Data
public class RecordDTO {
    private Integer recordId;
    private Integer account;
    private Boolean isRead;
    private Integer term;
    private Instant createTime;
    private List<WarningDTO> warningList;
}
