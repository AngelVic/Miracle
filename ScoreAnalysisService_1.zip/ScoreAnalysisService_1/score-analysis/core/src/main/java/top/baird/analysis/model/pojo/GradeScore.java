package top.baird.analysis.model.pojo;

import lombok.Data;

@Data
public class GradeScore {
    public Integer grade;
    public Integer totalNum;
    public Double gradeAB;
    public Double average;
    public Integer failNum;
    public Double subjectAB;
    public Double pass;
}
