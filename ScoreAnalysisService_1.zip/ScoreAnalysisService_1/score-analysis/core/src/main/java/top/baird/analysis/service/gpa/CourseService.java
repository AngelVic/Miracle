package top.baird.analysis.service.gpa;

import top.baird.analysis.model.dto.CourseDTO;

import java.util.List;
import java.util.Optional;

public interface CourseService {

    List<CourseDTO> getCourseList(Integer majorId);

    boolean exists(String courseName);

    List<CourseDTO> getCounselorCourseList(Integer gradeId,Integer term);

    List<CourseDTO> getClassScoreCourseList(Integer classId,Integer term);

    void insertList(List<List<Object>> courseList);

    Optional<Integer> findIdByName(String courseName);

    Optional<String> findNameById(Integer courseId);

    Optional<Double> findCreditById(Integer courseId);

}
