package top.baird.analysis.model.dto;

import lombok.Data;
import top.baird.analysis.model.able.JsonAble;

import java.time.Instant;

@Data
public class FileDTO implements JsonAble {
    private Integer id;
    private String url;
    private Integer account;
    private Integer gradeId;
    private Integer term;
    private Integer state;
    private String fileName;
    private Instant createTime;
}
