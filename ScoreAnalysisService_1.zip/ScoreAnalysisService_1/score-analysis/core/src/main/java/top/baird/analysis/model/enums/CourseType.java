package top.baird.analysis.model.enums;

public enum CourseType {

    GGBX("公共必修"),XKBX("学科必修"),SJHJ("实践环节"),GGYSL("公共艺术类"),RWSKL("人文社科类");

    public final String name;

    CourseType(String name) {
        this.name = name;
    }

}
