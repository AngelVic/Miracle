package top.baird.analysis.model.dto;

import lombok.Data;

import java.time.Instant;

@Data
public class CounselorDTO {

    private Integer id;
    private Integer account;
    private Integer gradeId;
    private String name;
    private Instant createTime;

}
