package top.baird.analysis.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TermGrade {
    public Integer term;
    public Double gradePoint;
}
