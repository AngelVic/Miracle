package top.baird.analysis.service.gpa;

import top.baird.analysis.model.dto.MajorDTO;
import top.baird.analysis.model.dto.QuotaDTO;
import top.baird.analysis.model.dto.ScoreDTO;

import java.util.List;
import java.util.Optional;

public interface QuotaService {

    QuotaDTO findQuota(Integer account);

    boolean exists(Integer account);

    void createDefault(Integer account);

    void update(QuotaDTO quotaDTO);

}
