package top.baird.analysis.util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import top.baird.analysis.ex.CustomParamException;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {

    /**
     * 根据文件后缀名类型获取对应的工作簿对象
     * @param inputStream 读取文件的输入流
     * @param fileType    文件后缀名类型（xls或xlsx）
     * @return 包含文件数据的工作簿对象
     */
    private static Workbook getWorkbook(InputStream inputStream, String fileType) throws IOException {
        //用自带的方法新建工作薄
        Workbook workbook = WorkbookFactory.create(inputStream);
        //后缀判断有版本转换问题
        //Workbook workbook = null;
        //if (fileType.equalsIgnoreCase(XLS)) {
        //    workbook = new HSSFWorkbook(inputStream);
        //} else if (fileType.equalsIgnoreCase(XLSX)) {
        //    workbook = new XSSFWorkbook(inputStream);
        //}
        return workbook;
    }


    public static List<List<Object>> parseExcel(InputStream in, String fileName) throws CustomParamException, IOException {
        List list = new ArrayList<>();
        Workbook work = getWorkbook(in, fileName);
        if (null == work) {
            throw CustomParamException.of("创建Excel工作薄为空！");
        }
        Sheet sheet = null;
        Row row = null;
        Cell cell = null;
        for (int i = 0; i < work.getNumberOfSheets(); i++) {
            sheet = work.getSheetAt(i);
            if (sheet == null) {
                continue;
            }
            int firstRowNum=sheet.getFirstRowNum();
            boolean sign=false;
            for (int j = firstRowNum; j <= sheet.getLastRowNum(); j++) {
                row = sheet.getRow(j);
                if (row == null) {
                    continue;
                }
                Cell tool=row.getCell(row.getFirstCellNum());
                tool.setCellType(CellType.STRING);
                if (tool.getStringCellValue().equals("选课时间")){
                    sign=true;
                    String[] check=new String[]{"选课时间","学号","姓名","课程名称","学分","百分成绩","五分成绩","考试类型","选修类型"};
                    int firstNum=row.getFirstCellNum();
                    for (int y = firstNum; y <  firstNum+9; y++) {
                        cell = row.getCell(y);
                        if (!check[y-firstNum].equals(cell.getStringCellValue())){
                            throw CustomParamException.of("上传文件格式错误");
                        }
                    }
                    continue;
                }
                List<Object> li = new ArrayList<>();
                if (sign){
                    for (int y = row.getFirstCellNum(); y < row.getLastCellNum(); y++) {

                        if (y==row.getFirstCellNum()+1){
                            cell = row.getCell(y);
                            BigDecimal decimal = new BigDecimal(cell.toString());
                            int scale = decimal.scale();
                            String value;
                            if (scale < 1) {
                                DecimalFormat df = new DecimalFormat("0");
                                value = df.format(decimal);
                            } else {
                                value = String.valueOf(decimal);
                            }
                            li.add(value);
                        }else {
                            cell = row.getCell(y);
                            li.add(cell);
                        }
                    }
                    list.add(li);
                }
            }
        }
        return list;

    }

}
