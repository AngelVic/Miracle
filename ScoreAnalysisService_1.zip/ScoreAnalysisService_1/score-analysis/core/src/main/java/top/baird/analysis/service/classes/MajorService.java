package top.baird.analysis.service.classes;

import top.baird.analysis.model.dto.MajorDTO;

import java.util.List;
import java.util.Optional;

public interface MajorService {

    List<MajorDTO> getMajorList(Integer account);

    Optional<String> findMajorByGradeId(Integer gradeId);

}
