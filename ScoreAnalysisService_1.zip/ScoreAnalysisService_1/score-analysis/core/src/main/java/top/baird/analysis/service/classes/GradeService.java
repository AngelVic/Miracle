package top.baird.analysis.service.classes;

import top.baird.analysis.model.dto.GradeDTO;
import top.baird.analysis.model.pojo.CounselorDetail;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface GradeService {

    Optional<Integer> findMajorIdByGradeId(Integer gradeId);

    Optional<GradeDTO> findById(Integer gradeId);

    Set<Integer> findGradeIdsByMajorId(Integer majorId);

    Optional<Integer> findNumById(Integer gradeId);

    CounselorDetail getCounselorDetail(Integer account);

    List<GradeDTO> findGradeList(List<Integer> gradeIdList);

    List<Integer> findGradeIdByAdmin(Integer account);

    boolean exists(Integer gradeId);
}
