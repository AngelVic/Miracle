package top.baird.analysis.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class ClassScore {

    private Integer studentId;

    private String name;

    private Double gradePoint;

    private List<SubjectScore> scoreList;

}
