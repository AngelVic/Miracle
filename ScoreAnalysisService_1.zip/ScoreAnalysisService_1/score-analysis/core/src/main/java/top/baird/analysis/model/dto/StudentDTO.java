package top.baird.analysis.model.dto;

import lombok.Data;

@Data
public class StudentDTO {
    private Integer studentId;
    private Integer classId;
    private Boolean isSpecial;
    private Integer building;
    private Integer gradeId;
    private Integer majorId;
    private Integer room;
    private String name;
}
