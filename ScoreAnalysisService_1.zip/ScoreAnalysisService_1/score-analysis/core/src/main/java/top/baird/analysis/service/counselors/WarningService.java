package top.baird.analysis.service.counselors;

import top.baird.analysis.model.dto.RecordDTO;

import java.util.List;

public interface WarningService {

    void createWarning(Integer account,Integer term);

    void allIsRead(Integer account);

    void isRead(Integer recordId);

    List<RecordDTO> getListByAccountAndIsRead(Integer account, Boolean isRead);

}
