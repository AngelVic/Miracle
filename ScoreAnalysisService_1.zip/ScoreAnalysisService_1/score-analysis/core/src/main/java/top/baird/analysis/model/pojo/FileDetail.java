package top.baird.analysis.model.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
public class FileDetail {

    private Integer fileId;
    private Integer grade;
    private String majorName;
    private Integer term;
    private String admin;
    private String fileUrl;
    private String fileName;
    private Instant uploadTime;
    private Integer state;

}
