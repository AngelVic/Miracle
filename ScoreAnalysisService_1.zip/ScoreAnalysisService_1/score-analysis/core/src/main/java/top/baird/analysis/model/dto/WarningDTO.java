package top.baird.analysis.model.dto;

import lombok.Data;

@Data
public class WarningDTO {
    private Integer id;
    private Integer studentId;
    private Integer recordId;
    private Integer failNum;
    private String studentName;
    private Integer building;
    private Integer room;
}

