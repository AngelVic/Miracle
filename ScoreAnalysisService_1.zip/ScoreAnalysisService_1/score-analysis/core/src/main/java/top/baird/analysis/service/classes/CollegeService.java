package top.baird.analysis.service.classes;

public interface CollegeService {
}
