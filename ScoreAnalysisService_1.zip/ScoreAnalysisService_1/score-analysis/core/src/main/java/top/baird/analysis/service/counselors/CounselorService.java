package top.baird.analysis.service.counselors;

import top.baird.analysis.model.dto.CounselorDTO;

import java.util.List;

public interface CounselorService {

    void insert(CounselorDTO counselorDTO);

    void update(Integer account,List<Integer> gradeIdList);

    void delete(Integer account);

    List<Integer> findGradeIdByAccount(Integer account);

    List<CounselorDTO> findListByGradeId(Integer gradeId,String key);

}
