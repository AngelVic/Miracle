package top.baird.analysis.service.student;

import top.baird.analysis.model.dto.StudentDTO;
import top.baird.analysis.model.pojo.StudentDetail;

import java.util.List;
import java.util.Optional;

public interface StudentService {

    Optional<StudentDTO> findByStudentId(Integer studentId);

    Optional<String> findNameById(Integer studentId);

    boolean exists(Integer studentId);

    boolean findIsSpecial(Integer studentId);

    void update(StudentDTO studentDTO);

    Optional<Integer> findMajorId(Integer studentId);

    Optional<Integer> findClassIdByStudentNum(Integer studentId);

    void insertList(List<List<Object>> student,Integer gradeId);


    List<StudentDTO> findStudentListByIds(List<Integer> studentIdList);

    List<StudentDTO> findStudentListByClassId(Integer classId);

    List<StudentDTO> findStudentListByClassIdAndKey(Integer classId,String key);

    StudentDetail findStudentScore(Integer studentId, Integer term);

    Optional<Integer> findNumByClassId(Integer classId);

}
