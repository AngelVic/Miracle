package top.baird.analysis.service.file;

import top.baird.analysis.model.dto.FileDTO;
import top.baird.analysis.model.pojo.FileDetail;

import java.io.InputStream;
import java.util.List;
import java.util.Optional;

public interface FileService {

    boolean existAccount(Integer account);

    boolean existTerm(Integer term);

    void deleteFiles(List<Integer> fileIdList);

    String uploadFileAvatar(InputStream inputStream, String module, String originalFilename, String type);

    Optional<Integer> insertFile(FileDTO fileDTO);

    List<FileDetail> findList(Integer account, Integer gradeId, Integer term);

    List<Integer> findIdList(Integer account);

    Optional<Integer> handling(List<List<Object>> list,Integer fileId,Integer gradeId);
}
