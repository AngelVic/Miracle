package top.baird.analysis.model;

import lombok.Getter;
import org.springframework.http.HttpStatus;
import top.baird.analysis.model.able.JsonAble;

/**
 * @author
 * @date 2022/3/7
 **/
@Getter
public class Result<T> implements JsonAble {
    private final int code;
    private final String msg;
    private final T data;

    public static <T> Result<T> of(HttpStatus httpStatus, String msg, T data) {
        return new Result<T>(httpStatus.value(), msg, data);
    }

    public static <T> Result<T> success(T data) {
        return of(HttpStatus.OK, "", data);
    }

    public static <T> Result<T> failure(String msg) {
        return of(HttpStatus.INTERNAL_SERVER_ERROR, msg, null);
    }

    public static <T> Result<T> reject(String msg) {
        return of(HttpStatus.BAD_REQUEST, msg, null);
    }


    private Result(int code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }
}
