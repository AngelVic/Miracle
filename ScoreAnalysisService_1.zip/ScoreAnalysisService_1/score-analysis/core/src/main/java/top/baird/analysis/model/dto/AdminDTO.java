package top.baird.analysis.model.dto;

import lombok.Data;
import top.baird.analysis.model.able.JsonAble;

import java.time.Instant;

@Data
public class AdminDTO implements JsonAble {
    private Integer accountId;
    private String pwd;
    private Instant createTime;
}
