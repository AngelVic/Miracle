package top.baird.analysis.ex;

import com.alibaba.fastjson.JSON;

/**
 * @author
 * @date 2021/10/26
 */
public class CustomParamException extends RuntimeException {
    private CustomParamException(String message) {
        super(message);
    }

    public static CustomParamException of(String message, Object... args) {
        for (Object arg : args) {
            message = message.replace("{}", JSON.toJSONString(arg));
        }
        return new CustomParamException(message);
    }
}
