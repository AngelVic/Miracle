package top.baird.analysis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.baird.analysis.po.Student;

public interface StudentMapper extends BaseMapper<Student> {
}
