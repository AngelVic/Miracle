package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class StudentVO {

    @ApiModelProperty("学号")
    public final Integer studentId;

    @ApiModelProperty("是否是港澳台")
    public final Boolean isSpecial;

    @ApiModelProperty("宿舍楼")
    public final Integer building;

    @ApiModelProperty("宿舍号")
    public final Integer room;

    @ApiModelProperty("学生姓名")
    public final String name;

}
