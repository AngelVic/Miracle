package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class TermGradeVO {

    @ApiModelProperty("学期")
    public final Integer term;

    @ApiModelProperty("绩点")
    public final Double gradePoint;

}
