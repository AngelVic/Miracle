package top.baird.analysis.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.ToString;

@ApiModel
@ToString
@AllArgsConstructor
public class StudentEdit {

    @ApiModelProperty(value = "学号",required = true)
    public Integer studentId;

    @ApiModelProperty(value = "是否是港澳台")
    public Boolean isSpecial;

    @ApiModelProperty(value = "宿舍楼号")
    public Integer building;

    @ApiModelProperty(value = "宿舍号")
    public Integer room;

    @ApiModelProperty(value = "班级Id")
    public Integer classId;


}
