package top.baird.analysis.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.StudentMapper;
import top.baird.analysis.model.dto.StudentDTO;
import top.baird.analysis.model.pojo.StudentDetail;
import top.baird.analysis.model.pojo.TermGrade;
import top.baird.analysis.po.Student;
import top.baird.analysis.service.classes.ClassService;
import top.baird.analysis.service.classes.GradeService;
import top.baird.analysis.service.gpa.ScoreService;
import top.baird.analysis.service.student.StudentService;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StudentServiceImpl implements StudentService {

    @Resource
    StudentMapper studentMapper;

    @Resource
    ClassService classService;

    @Resource
    GradeService gradeService;

    @Resource
    ScoreService scoreService;

    @Override
    public Optional<StudentDTO> findByStudentId(Integer studentId){
        return Optional.ofNullable(studentMapper.selectById(studentId)).map(this::toDTO);
    }

    @Override
    public Optional<String> findNameById(Integer studentId){
        return Optional.ofNullable(studentMapper.selectById(studentId).getName());
    }

    @Override
    public Optional<Integer> findMajorId(Integer studentId){
        StudentDTO studentDTO=findByStudentId(studentId).orElse(null);
        assert studentDTO != null;
        return Optional.ofNullable(studentDTO.getMajorId());
    }

    @Override
    public boolean findIsSpecial(Integer studentId){
        return studentMapper.selectById(studentId).getIsSpecial();
    }

    @Override
    public Optional<Integer> findClassIdByStudentNum(Integer studentId){
        return Optional.ofNullable(studentMapper.selectById(studentId).getClassId());
    }

    @Override
    public boolean exists(Integer studentId){
        return studentId != null &&
                studentMapper.selectCount(Wrappers.lambdaQuery(Student.class)
                        .eq(Student::getStudentId, studentId)
                ) > 0;
    }

    @Override
    public void update(StudentDTO studentDTO){
        Student student = new Student() {{
            setStudentId(studentDTO.getStudentId());
            setBuilding(studentDTO.getBuilding());
            setIsSpecial(studentDTO.getIsSpecial());
            setRoom(studentDTO.getRoom());
            setClassId(studentDTO.getClassId());
        }};
        studentMapper.update(student, Wrappers.lambdaQuery(Student.class)
                .eq(Student::getStudentId, studentDTO.getStudentId())
        );
    }



    @Override
    public List<StudentDTO> findStudentListByIds(List<Integer> studentIdList){
        return studentMapper.selectBatchIds(studentIdList)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<StudentDTO> findStudentListByClassIdAndKey(Integer classId,String key){
        return studentMapper.selectList(Wrappers.lambdaQuery(Student.class)
                .like(key!=null,Student::getName,key)
                .or().like(key!=null,Student::getStudentId,key)
                .eq(Student::getClassId,classId)
        )
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public StudentDetail findStudentScore(Integer studentId, Integer term){
        List<Integer> rank=scoreService.findClassRankAndGradeRank(studentId,term);
        Integer classRank=rank.get(0);
        Integer gradeRank=rank.get(1);
        List<TermGrade> gradeList=scoreService.findGradeListByStudentIdAndTerm(studentId,term);
        return new StudentDetail(findByStudentId(studentId).orElse(null),classRank,gradeRank,gradeList);
    }

    @Override
    public List<StudentDTO> findStudentListByClassId(Integer classId){
        return studentMapper.selectList(Wrappers.lambdaQuery(Student.class)
                .eq(Student::getClassId,classId)
        )
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList()
                );
    }

    @Override
    public void insertList(List<List<Object>> studentList,Integer gradeId){
        for (int i=0;i<studentList.size();i++){
            int index=i;
            String num=studentList.get(index).get(0).toString();
            Integer studentId=Integer.parseInt(num);
            Integer classId=classService.toFindClassId(num,gradeId).orElse(0);

            if (!exists(studentId)){
                Student student=new Student(){
                    {
                        setStudentId(studentId);
                        setName(studentList.get(index).get(1).toString());
                        setClassId(classId);
                    }
                };
                try {
                    studentMapper.insert(student);
                } catch (DuplicateKeyException e) {
                    return;
                }
            }
        }
    }

    @Override
    public Optional<Integer> findNumByClassId(Integer classId){
        return Optional.ofNullable(studentMapper.selectCount(Wrappers.lambdaQuery(Student.class)
                .eq(Student::getClassId,classId)
        ));
    }

    private StudentDTO toDTO(Student student) {
        StudentDTO st = new StudentDTO();
        st.setBuilding(student.getBuilding());
        st.setStudentId(student.getStudentId());
        st.setClassId(student.getClassId());
        st.setRoom(student.getRoom());
        st.setIsSpecial(student.getIsSpecial());
        st.setGradeId(classService.findGradeIdByClassId(student.getClassId()).orElse(0));
        st.setMajorId(gradeService.findMajorIdByGradeId(st.getGradeId()).orElse(0));
        st.setName(student.getName());
        return st;
    }

}
