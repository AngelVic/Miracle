package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class StudentBriefVO {

    @ApiModelProperty("学号")
    public final Integer studentId;

    @ApiModelProperty("姓名")
    public final String name;

}
