package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import top.baird.analysis.model.dto.StudentDTO;

import java.util.List;

@ApiModel
public class StudentDetailVO extends StudentVO{

    @ApiModelProperty("班级排名")
    public final Integer classRank;

    @ApiModelProperty("年级排名")
    public final Integer gradeRank;

    @ApiModelProperty("学期-成绩列表")
    public final List<TermGradeVO> gradeList;

    public StudentDetailVO(Integer studentId, Boolean isSpecial, Integer building,Integer room,String name, Integer classRank,Integer gradeRank,List<TermGradeVO> gradeList) {
        super(studentId, isSpecial, building, room,name);
        this.classRank = classRank;
        this.gradeRank=gradeRank;
        this.gradeList=gradeList;
    }

    public StudentDetailVO(StudentDTO studentDTO, Integer classRank, Integer gradeRank,List<TermGradeVO> gradeList) {
        this(studentDTO.getStudentId(), studentDTO.getIsSpecial(),studentDTO.getBuilding(), studentDTO.getRoom(),studentDTO.getName(),classRank,gradeRank,gradeList);
    }

}
