package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;
import top.baird.analysis.ex.CustomParamException;
import top.baird.analysis.model.Result;
import top.baird.analysis.model.dto.StudentDTO;
import top.baird.analysis.po.Student;
import top.baird.analysis.req.StudentEdit;
import top.baird.analysis.service.student.StudentService;
import top.baird.analysis.vo.StudentBriefVO;
import top.baird.analysis.vo.StudentDetailVO;
import top.baird.analysis.vo.StudentVO;
import top.baird.analysis.vo.TermGradeVO;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/student")
public class StudentController {

    @Resource
    StudentService studentService;

    @PostMapping
    @ApiOperation(value="编辑学生信息",tags = "学生信息")
    public Result<Void> editStudent(@RequestBody @Valid StudentEdit studentEdit){
        if (!studentService.exists(studentEdit.studentId)){
            throw CustomParamException.of("学生 {} 不存在",studentEdit.studentId);
        }
        StudentDTO studentDTO = new StudentDTO() {{
            setClassId(studentEdit.classId);
            setStudentId(studentEdit.studentId);
            setIsSpecial(studentEdit.isSpecial);
            setBuilding(studentEdit.building);
            setRoom(studentEdit.room);
        }};        studentService.update(studentDTO);
        return Result.success(null);
    }

    @GetMapping
    @ApiOperation(value = "查找学生信息列表",tags = "学生信息",notes = "加了搜索功能，key不为空时即为搜索")
    public Result<List<StudentVO>> findStudentList(@ApiParam("班级id") Integer classId,@ApiParam("关键字")String key){
        return Result.success(studentService.findStudentListByClassIdAndKey(classId,key)
                .stream()
                .map(studentDTO -> new StudentVO(
                        studentDTO.getStudentId(),
                        studentDTO.getIsSpecial(),
                        studentDTO.getBuilding(),
                        studentDTO.getRoom(),
                        studentDTO.getName())
                )
                .collect(Collectors.toList())
        );
    }


    @GetMapping("/score")
    @ApiOperation(value = "学生个人成绩",tags = "辅导员-学生个人成绩")
    public Result<StudentDetailVO> getStudentScore(@ApiParam("学号")Integer studentId, @ApiParam("学期")Integer term){
        return Result.success(Optional.ofNullable(studentService.findStudentScore(studentId,term))
                .map(studentDetail -> new StudentDetailVO(
                        studentDetail.getStudentDTO(),
                        studentDetail.getClassRank(),
                        studentDetail.getGradeRank(),
                        studentDetail.getGradeList()
                                .stream()
                                .map(termGrade -> new TermGradeVO(
                                        termGrade.getTerm(),
                                        termGrade.getGradePoint())
                                ).collect(Collectors.toList())
                        )
                ).orElse(null));
    }

    @GetMapping("/search")
    @ApiOperation(value = "搜索班级学生信息",tags = "辅导员-班级成绩")
    public Result<List<StudentBriefVO>> getStudentMessage(@ApiParam("关键词")String key,@ApiParam("班级id")Integer classId){
        return Result.success(studentService.findStudentListByClassIdAndKey(classId,key)
                .stream()
                .map(studentDTO -> new StudentBriefVO(
                        studentDTO.getStudentId(),
                        studentDTO.getName()
                ))
                .collect(Collectors.toList())
        );
    }

}
