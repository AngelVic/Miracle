package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import top.baird.analysis.model.Result;
import top.baird.analysis.service.auth.AccountService;
import top.baird.analysis.service.classes.GradeService;
import top.baird.analysis.service.counselors.CounselorService;
import top.baird.analysis.vo.AccountCounselorVO;
import top.baird.analysis.vo.GradeVO;

import javax.annotation.Resource;
import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/grade")
public class GradeController {

    @Resource
    CounselorService counselorService;

    @Resource
    GradeService gradeService;

    @GetMapping
    @ApiOperation(value = "获取辅导员管理年级信息列表",tags = "辅导员-年级成绩")
    public Result<List<GradeVO>> getGradeIdByAccount(@ApiParam("辅导员账号") Integer account){
        List<Integer> gradeIdList=counselorService.findGradeIdByAccount(account);
        return Result.success(gradeService.findGradeList(gradeIdList)
                .stream()
                .map(gradeDTO -> new GradeVO(
                        gradeDTO.getId(),
                        gradeDTO.getGrade(),
                        gradeDTO.getMajorName()
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/admin")
    @ApiOperation(value = "获取管理员管理年级信息列表",tags = "管理员-负责人信息")
    public Result<List<GradeVO>> getOrganizationId(@ApiParam("管理员账号") Integer account){
        List<Integer> gradeIdList=gradeService.findGradeIdByAdmin(account);
        return Result.success(gradeService.findGradeList(gradeIdList)
                .stream()
                .map(gradeDTO -> new GradeVO(
                        gradeDTO.getId(),
                        gradeDTO.getGrade(),
                        gradeDTO.getMajorName()
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/counselor")
    @ApiOperation(value = "获取辅导员详情",tags = "管理员-负责人管理")
    public Result<AccountCounselorVO> counselorDetail(@ApiParam("辅导员账号")@RequestParam("counselor-account") Integer account){
        return Result.success(Optional.of(gradeService.getCounselorDetail(account))
                .map(cd -> new AccountCounselorVO(
                        cd.getAccount(),
                        cd.getGradeList()
                                .stream()
                                .map(gradeDTO -> new GradeVO(
                                gradeDTO.getId(),
                                gradeDTO.getGrade(),
                                gradeDTO.getMajorName()))
                                .collect(Collectors.toList()),
                        cd.getName()
                )).orElse(null));
    }

}
