package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class ClassVO {

    @ApiModelProperty("班级id")
    public final Integer classId;

    @ApiModelProperty("班级名")
    public final Integer name;

}
