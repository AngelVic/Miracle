package top.baird.analysis.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.MajorMapper;
import top.baird.analysis.model.dto.MajorDTO;
import top.baird.analysis.po.Major;
import top.baird.analysis.service.auth.AdminService;
import top.baird.analysis.service.classes.GradeService;
import top.baird.analysis.service.classes.MajorService;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MajorServiceImpl implements MajorService {

    @Resource
    private MajorMapper majorMapper;

    @Resource
    private AdminService adminService;

    @Resource
    private GradeService gradeService;

    @Override
    public List<MajorDTO> getMajorList(Integer account){
        Integer collegeId=adminService.findCollegeByAccount(account).orElse(0);
        return majorMapper.selectList(Wrappers.lambdaQuery(Major.class)
                .eq(Major::getCollegeId,collegeId)
        )
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<String> findMajorByGradeId(Integer gradeId){
        Integer majorId=gradeService.findMajorIdByGradeId(gradeId).orElse(0);
        return Optional.ofNullable(majorMapper.selectOne(Wrappers.lambdaQuery(Major.class)
                .eq(Major::getMajorId,majorId))
                .getName()
        );
    }

    private MajorDTO toDTO(Major major) {
        MajorDTO majorDTO = new MajorDTO();
        majorDTO.setMajorId(major.getMajorId());
        majorDTO.setMajorCode(major.getMajorCode());
        majorDTO.setCollegeId(major.getCollegeId());
        majorDTO.setName(major.getName());
        return majorDTO;
    }

}
