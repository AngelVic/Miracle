package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class ClassDetailVO {

    @ApiModelProperty("班级id")
    public final Integer classId;

    @ApiModelProperty("班级名")
    public final Integer name;

    @ApiModelProperty("专业年级id")
    public final Integer gradeId;

    @ApiModelProperty("年级")
    public final Integer grade;

    @ApiModelProperty("专业")
    public final String major;
}
