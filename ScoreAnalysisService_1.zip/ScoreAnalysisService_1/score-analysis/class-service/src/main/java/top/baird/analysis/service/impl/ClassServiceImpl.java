package top.baird.analysis.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.ClassMapper;
import top.baird.analysis.mapper.CollegeMapper;
import top.baird.analysis.mapper.GradeMapper;
import top.baird.analysis.mapper.MajorMapper;
import top.baird.analysis.model.dto.ClassDTO;
import top.baird.analysis.po.Class;
import top.baird.analysis.po.Major;
import top.baird.analysis.service.classes.ClassService;
import top.baird.analysis.service.classes.GradeService;
import top.baird.analysis.service.classes.MajorService;
import top.baird.analysis.service.counselors.CounselorService;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClassServiceImpl implements ClassService {

    @Resource
    ClassMapper classMapper;

    @Resource
    GradeService gradeService;

    @Resource
    MajorService majorService;

    @Resource
    CounselorService counselorService;

    @Resource
    GradeMapper gradeMapper;

    @Resource
    MajorMapper majorMapper;

    @Resource
    CollegeMapper collegeMapper;

    @Override
    public Optional<Integer> findGradeIdByClassId(Integer classId){
        return Optional.ofNullable(classMapper.selectById(classId).getGradeId());
    }

    @Override
    public boolean exists(Integer classId){
        return classId != null &&
                classMapper.selectCount(Wrappers.lambdaQuery(Class.class)
                        .eq(Class::getClassId, classId)
                ) > 0;
    }

    @Override
    public Optional<Integer> toFindClassId(String value,Integer gradeId){
        char[] studentChar=value.toCharArray();
        Integer majorId=gradeMapper.selectById(gradeId).getMajorId();
        Integer termNum=gradeMapper.selectById(gradeId).getGradeNum()-2000;
        Integer currentTerm=Integer.valueOf(studentChar[studentChar.length-7]+""+studentChar[studentChar.length-6]);
        Major major=majorMapper.selectById(majorId);
        Integer majorCode=major.getMajorCode();
        Integer currentMajor=Integer.valueOf(studentChar[studentChar.length-5]+""+studentChar[studentChar.length-4]);
        Integer collegeCode=collegeMapper.selectById(major.getCollegeId()).getCode();
        Integer currentCollege=studentChar.length>8?Integer.valueOf(studentChar[0]+""+studentChar[1]):Integer.valueOf(studentChar[0]+"");
        int classNum;
        if (!majorCode.equals(currentMajor)||!collegeCode.equals(currentCollege)||!termNum.equals(currentTerm)){
            classNum=0;
        }else {
            classNum= Integer.parseInt(studentChar[studentChar.length - 3] + "");
        }
        Class c=classMapper.selectOne(Wrappers.lambdaQuery(Class.class)
                .eq(Class::getName, classNum)
                .eq(Class::getGradeId,gradeId)
        );
        if(c==null){
            Class insert=new Class(){
                {
                    setName(classNum);
                    setGradeId(gradeId);
                }
            };
            classMapper.insert(insert);
            return Optional.ofNullable(insert.getClassId());
        }
        return Optional.ofNullable(c.getClassId());
    }

    @Override
    public List<ClassDTO> findClassListByGradeId(Integer gradeId){
        return classMapper.selectList(Wrappers.lambdaQuery(Class.class)
                .eq(Class::getGradeId,gradeId)
        )
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<ClassDTO> findClassDetailByAccount(Integer account){
        List<Integer> gradeIdList=counselorService.findGradeIdByAccount(account);
        return classMapper.selectList(Wrappers.lambdaQuery(Class.class)
                .in(Class::getGradeId,gradeIdList)
        )
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    @Override
    public Optional<Integer> findClassIdByAll(Integer gradeId,Integer classNum){
        return Optional.ofNullable(classMapper.selectOne(Wrappers.lambdaQuery(Class.class)
                .eq(Class::getGradeId,gradeId)
                .eq(Class::getName,classNum)
        ).getClassId());
    }

    private ClassDTO toDTO(Class c) {
        ClassDTO classDTO = new ClassDTO();
        classDTO.setClassId(c.getClassId());
        classDTO.setName(c.getName());
        classDTO.setGradeId(c.getGradeId());
        classDTO.setGrade(gradeService.findNumById(classDTO.getGradeId()).orElse(0));
        classDTO.setMajor(majorService.findMajorByGradeId(classDTO.getGradeId()).orElse(null));
        return classDTO;
    }

}
