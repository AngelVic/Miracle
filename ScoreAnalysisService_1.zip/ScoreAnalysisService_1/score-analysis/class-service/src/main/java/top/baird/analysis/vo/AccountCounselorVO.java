package top.baird.analysis.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

import java.util.List;

@ApiModel
@AllArgsConstructor
public class AccountCounselorVO {

    @ApiModelProperty("账号")
    public final Integer account;

    @ApiModelProperty("年级专业信息列表")
    public final List<GradeVO> gradeList;

    @ApiModelProperty("姓名")
    public final String name;

}
