package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class GradeVO {

    @ApiModelProperty("年级专业id")
    public final Integer id;

    @ApiModelProperty("年级")
    public final Integer grade;

    @ApiModelProperty("专业名")
    public final String majorName;

}
