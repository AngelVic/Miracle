package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;
import top.baird.analysis.model.Result;
import top.baird.analysis.service.classes.ClassService;
import top.baird.analysis.service.classes.MajorService;
import top.baird.analysis.service.gpa.CourseService;
import top.baird.analysis.vo.MajorVO;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/major")
public class MajorController {

    @Resource
    MajorService majorService;

    @GetMapping
    @ApiOperation(value = "获取学院管理的专业列表",tags = "管理员-年级成绩对比")
    public Result<List<MajorVO>> getMajorList(@ApiParam("管理员账号") @RequestParam("admin-account") Integer account){
        return Result.success(majorService.getMajorList(account)
                .stream()
                .map(majorDTO -> new MajorVO(
                        majorDTO.getMajorId(),
                        majorDTO.getName()
                    )
                )
                .collect(Collectors.toList())
        );
    }


}
