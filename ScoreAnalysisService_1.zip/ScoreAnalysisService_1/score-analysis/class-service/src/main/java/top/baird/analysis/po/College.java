package top.baird.analysis.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

@Data
public class College {
    @TableId(type = IdType.AUTO)
    private Integer collegeId;
    private String name;
    private Integer code;
}
