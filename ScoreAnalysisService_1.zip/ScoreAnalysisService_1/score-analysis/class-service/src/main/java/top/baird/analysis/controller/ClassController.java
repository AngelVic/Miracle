package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.baird.analysis.model.Result;
import top.baird.analysis.service.classes.ClassService;
import top.baird.analysis.vo.ClassDetailVO;
import top.baird.analysis.vo.ClassVO;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/class")
public class ClassController {

    @Resource
    ClassService classService;

    @GetMapping
    @ApiOperation(value = "获取专业年级下属班级",tags = {"学生信息","成绩分析-班级成绩"})
    public Result<List<ClassVO>> findClassByGradeId(@ApiParam("年级id") Integer gradeId){
        return Result.success(classService.findClassListByGradeId(gradeId)
                .stream()
                .map(classDTO -> new ClassVO(
                        classDTO.getClassId(),
                        classDTO.getName()
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/counselor")
    @ApiOperation(value = "辅导员所管理班级列表",tags = "辅导员-班级成绩")
    public Result<List<ClassDetailVO>> findClassDetailByAccount(@ApiParam("账号") Integer account){
        return Result.success(classService.findClassDetailByAccount(account)
                .stream().map(classDTO -> new ClassDetailVO(
                        classDTO.getClassId(),
                        classDTO.getName(),
                        classDTO.getGradeId(),
                        classDTO.getGrade(),
                        classDTO.getMajor()
                )).collect(Collectors.toList())
        );
    }

}
