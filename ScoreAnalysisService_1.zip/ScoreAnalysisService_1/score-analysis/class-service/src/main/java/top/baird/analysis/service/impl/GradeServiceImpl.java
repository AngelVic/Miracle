package top.baird.analysis.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.GradeMapper;
import top.baird.analysis.mapper.MajorMapper;
import top.baird.analysis.model.dto.GradeDTO;
import top.baird.analysis.model.pojo.CounselorDetail;
import top.baird.analysis.po.Grade;
import top.baird.analysis.po.Major;
import top.baird.analysis.service.auth.AccountService;
import top.baird.analysis.service.auth.AdminService;
import top.baird.analysis.service.classes.GradeService;
import top.baird.analysis.service.counselors.CounselorService;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class GradeServiceImpl implements GradeService {

    @Resource
    GradeMapper gradeMapper;

    @Resource
    MajorMapper majorMapper;

    @Resource
    AdminService adminService;

    @Resource
    AccountService accountService;

    @Resource
    CounselorService counselorService;

    @Override
    public Optional<Integer> findMajorIdByGradeId(Integer gradeId){
        return Optional.ofNullable(gradeMapper.selectById(gradeId).getMajorId());
    }

    @Override
    public Set<Integer> findGradeIdsByMajorId(Integer majorId){
        return gradeMapper.selectList(Wrappers.lambdaQuery(Grade.class)
                .eq(Grade::getMajorId,majorId))
                .stream()
                .map(Grade::getGradeId)
                .collect(Collectors.toSet());
    }

    @Override
    public Optional<GradeDTO> findById(Integer gradeId){
        return Optional.of(gradeMapper.selectById(gradeId)).map(this::toDTO);
    }

    @Override
    public List<GradeDTO> findGradeList(List<Integer> gradeIdList){
        return gradeMapper.selectBatchIds(gradeIdList)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList()
                );
    }

    @Override
    public CounselorDetail getCounselorDetail(Integer account){
        List<Integer> gradeIdList=counselorService.findGradeIdByAccount(account);
        List<GradeDTO> gradeDTOS=gradeMapper.selectBatchIds(gradeIdList)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
        String name=accountService.findCounselorName(account).orElse("");
        return new CounselorDetail(account,gradeDTOS,name);
    }

    @Override
    public List<Integer> findGradeIdByAdmin(Integer account){
        Integer collegeId=adminService.findCollegeByAccount(account).orElse(0);
        List<Integer> majorIdList=majorMapper.selectList(Wrappers.lambdaQuery(Major.class)
                .eq(Major::getCollegeId,collegeId))
                .stream()
                .map(Major::getMajorId)
                .collect(Collectors.toList());
        return gradeMapper.selectList(Wrappers.lambdaQuery(Grade.class)
                .in(Grade::getMajorId,majorIdList))
                .stream()
                .map(Grade::getGradeId)
                .collect(Collectors.toList());
    }

    @Override
    public boolean exists(Integer gradeId){
        return gradeId != null &&
                gradeMapper.selectCount(Wrappers.lambdaQuery(Grade.class)
                        .eq(Grade::getGradeId, gradeId)
                ) > 0;
    }

    @Override
    public Optional<Integer> findNumById(Integer gradeId){
        return Optional.ofNullable(gradeMapper.selectById(gradeId).getGradeNum());
    }

    private GradeDTO toDTO(Grade grade) {
        GradeDTO gradeDTO = new GradeDTO();
        gradeDTO.setGrade(grade.getGradeNum());
        gradeDTO.setId(grade.getGradeId());
        gradeDTO.setMajorId(grade.getMajorId());
        gradeDTO.setMajorName(majorMapper.selectById(gradeDTO.getMajorId()).getName());
        return gradeDTO;
    }

}
