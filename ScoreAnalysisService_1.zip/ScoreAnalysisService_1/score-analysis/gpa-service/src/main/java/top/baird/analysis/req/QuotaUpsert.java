package top.baird.analysis.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.ToString;

import java.time.Instant;

@ApiModel
@ToString
@AllArgsConstructor
public class QuotaUpsert {

    @ApiModelProperty(value = "管理员账号",required = true)
    public Integer account;

    @ApiModelProperty(value = "普通学生及格线")
    public Double cutOff;

    @ApiModelProperty(value = "特殊学生及格线")
    public Double specialCutoff;

    @ApiModelProperty(value = "年级优秀率指标")
    public Double gradeAB;

    @ApiModelProperty(value = "班级绩点优秀率指标")
    public Double classAB;

    @ApiModelProperty(value = "班级科目优秀率指标")
    public Double subjectAB;

}
