package top.baird.analysis.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

@Data
public class Course {
    @TableId(type = IdType.AUTO)
    private Integer courseId;
    private String name;
    private String type;
    private Double credit;
}
