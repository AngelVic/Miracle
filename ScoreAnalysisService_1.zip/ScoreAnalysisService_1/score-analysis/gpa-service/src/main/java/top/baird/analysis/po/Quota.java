package top.baird.analysis.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

@Data
public class Quota {
    @TableId(type = IdType.INPUT)
    private Integer quotaId;
    private Double cutOff;
    private Double specialCutoff;
    private Double gradeAB;
    private Double classAB;
    private Double subjectAB;
    private Boolean isAdmin;
}
