package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class GradeScoreVO {

    @ApiModelProperty("年级")
    public final Integer grade;

    @ApiModelProperty("总人数")
    public final Integer totalNum;

    @ApiModelProperty("绩点优秀率")
    public final Double gradeAB;

    @ApiModelProperty("平均分")
    public final Double average;

    @ApiModelProperty("挂科人数")
    public final Integer failNum;

    @ApiModelProperty("科目优秀率")
    public final Double subjectAB;

    @ApiModelProperty("及格率")
    public final Double pass;

}
