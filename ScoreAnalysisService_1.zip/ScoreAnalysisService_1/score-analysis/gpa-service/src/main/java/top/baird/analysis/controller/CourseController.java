package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.baird.analysis.ex.CustomParamException;
import top.baird.analysis.model.Result;
import top.baird.analysis.service.classes.ClassService;
import top.baird.analysis.service.gpa.CourseService;
import top.baird.analysis.vo.CourseVO;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/course")
public class CourseController {

    @Resource
    CourseService courseService;

    @Resource
    ClassService classService;

    @GetMapping("/adminList")
    @ApiOperation(value = "获取专业下科目列表",tags = "管理员-年级成绩对比")
    public Result<List<CourseVO>> getAdminCourseList(@ApiParam("专业id") Integer majorId){
        return Result.success(courseService.getCourseList(majorId)
                .stream()
                .map(courseDTO -> new CourseVO(
                        courseDTO.getCourseId(),
                        courseDTO.getName()
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/counselorList")
    @ApiOperation(value = "获取年级成绩对比-科目列表",tags = "辅导员-年级成绩")
    public Result<List<CourseVO>> getCounselorCourseList(@ApiParam("年级专业id") Integer gradeId, @ApiParam("学期")Integer term){
        return Result.success(courseService.getCounselorCourseList(gradeId,term)
                .stream()
                .map(courseDTO -> new CourseVO(
                        courseDTO.getCourseId(),
                        courseDTO.getName()
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/classScore")
    @ApiOperation(value = "获取班级成绩下属科目列表",tags = "辅导员-班级成绩")
    public Result<List<CourseVO>> getClassScoreCourseList(@ApiParam("班级id") Integer classId, @ApiParam("学期")Integer term){
        if(!classService.exists(classId)){
            throw CustomParamException.of("班级id {} 不存在", classId);
        }
        return Result.success(courseService.getClassScoreCourseList(classId,term)
                .stream()
                .map(courseDTO -> new CourseVO(
                        courseDTO.getCourseId(),
                        courseDTO.getName()
                ))
                .collect(Collectors.toList())
        );
    }


}
