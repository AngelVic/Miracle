package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;
import top.baird.analysis.ex.CustomParamException;
import top.baird.analysis.model.Result;
import top.baird.analysis.model.dto.QuotaDTO;
import top.baird.analysis.req.QuotaUpsert;
import top.baird.analysis.service.gpa.QuotaService;
import top.baird.analysis.vo.CourseVO;
import top.baird.analysis.vo.QuotaVO;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/quota")
public class QuotaController {

    @Resource
    QuotaService quotaService;

    @GetMapping
    @ApiOperation(value = "获取优秀率规则",tags = "优秀率规则配置弹窗")
    public Result<QuotaVO> getQuota(@ApiParam("账号") Integer account){
        return Result.success(
                Optional.ofNullable(quotaService.findQuota(account))
                        .map(quotaDTO -> new QuotaVO(
                                quotaDTO.getCutOff(),
                                quotaDTO.getSpecialCutoff(),
                                quotaDTO.getGradeAB(),
                                quotaDTO.getClassAB(),
                                quotaDTO.getSubjectAB()
                        )).orElse(null)
        );
    }

    @PostMapping
    @ApiOperation(value="编辑优秀率规则",tags = "优秀率规则配置弹窗")
    public Result<Void> editQuota(@RequestBody @Valid QuotaUpsert quotaUpsert){
        if (!quotaService.exists(quotaUpsert.account)){
            throw CustomParamException.of("账号 {} 的规则不存在",quotaUpsert.account);
        }
        QuotaDTO quotaDTO = new QuotaDTO() {{
            setQuotaId(quotaUpsert.account);
            setSpecialCutoff(quotaUpsert.specialCutoff);
            setGradeAB(quotaUpsert.gradeAB);
            setCutOff(quotaUpsert.cutOff);
            setSubjectAB(quotaUpsert.subjectAB);
            setClassAB(quotaUpsert.classAB);
        }};
        quotaService.update(quotaDTO);
        return Result.success(null);
    }


}
