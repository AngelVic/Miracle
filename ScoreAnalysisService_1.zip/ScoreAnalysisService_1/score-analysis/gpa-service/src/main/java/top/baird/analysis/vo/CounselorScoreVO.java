package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class CounselorScoreVO {

    @ApiModelProperty("班级名")
    public final Integer classNum;

    @ApiModelProperty("总人数")
    public final Integer totalNum;

    @ApiModelProperty("绩点优秀率")
    public Double gradePointAB;

    @ApiModelProperty("平均分")
    public Double average;

    @ApiModelProperty("挂科人数")
    public Integer failNum;

    @ApiModelProperty("科目优秀率")
    public Double subjectAB;

    @ApiModelProperty("及格率")
    public Double pass;

}
