package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class ScoreComparisonVO {

    @ApiModelProperty("年级优秀率")
    public final Double gradeAB;

    @ApiModelProperty("班级优秀率")
    public final Double classAB;

    @ApiModelProperty("年级及格率")
    public final Double gradePass;

    @ApiModelProperty("班级及格率")
    public final Double classPass;

}
