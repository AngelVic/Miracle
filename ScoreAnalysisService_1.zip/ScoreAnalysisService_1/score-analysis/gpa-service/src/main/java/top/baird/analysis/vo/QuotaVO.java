package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class QuotaVO {
    @ApiModelProperty("普通学生及格线")
    public final Double cutOff;

    @ApiModelProperty("特殊学生及格线")
    public final Double specialCutoff;

    @ApiModelProperty("年级优秀率指标")
    public final Double gradeAB;

    @ApiModelProperty("班级绩点优秀率指标")
    public final Double classAB;

    @ApiModelProperty("班级科目优秀率指标")
    public final Double subjectAB;
}
