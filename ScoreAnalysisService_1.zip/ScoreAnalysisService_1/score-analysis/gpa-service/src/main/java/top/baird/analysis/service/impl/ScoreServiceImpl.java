package top.baird.analysis.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.ScoreMapper;
import top.baird.analysis.model.dto.ClassDTO;
import top.baird.analysis.model.dto.QuotaDTO;
import top.baird.analysis.model.dto.ScoreDTO;
import top.baird.analysis.model.dto.StudentDTO;
import top.baird.analysis.model.pojo.*;
import top.baird.analysis.po.Score;
import top.baird.analysis.service.classes.ClassService;
import top.baird.analysis.service.classes.GradeService;
import top.baird.analysis.service.gpa.CourseService;
import top.baird.analysis.service.gpa.QuotaService;
import top.baird.analysis.service.gpa.ScoreService;
import top.baird.analysis.service.student.StudentService;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ScoreServiceImpl implements ScoreService {

    @Resource
    StudentService studentService;

    @Resource
    ClassService classService;

    @Resource
    GradeService gradeService;

    @Resource
    QuotaService quotaService;

    @Resource
    ScoreMapper scoreMapper;

    @Resource
    CourseService courseService;

    @Override
    public void deleteFiles(List<Integer> fileIdList){
        for (int i:fileIdList){
            if (scoreMapper.selectCount(Wrappers.lambdaQuery(Score.class).eq(Score::getFileId,i))>0){
                scoreMapper.delete(Wrappers.lambdaQuery(Score.class).eq(Score::getFileId,i));
            }
        }
    }

    @Override
    public Set<Integer> getCourseIdList(Integer majorId){
        return scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
        )
                .stream()
                .map(this::toDTO)
                .filter(s -> s.getMajorId().equals(majorId))
                .map(ScoreDTO::getCourseId)
                .collect(Collectors.toSet());
    }

    @Override
    public Set<Integer> getCounselorCourseIdList(Integer gradeId,Integer term){
        return scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                .eq(Score::getTerm,term)
        )
                .stream()
                .map(this::toDTO)
                .filter(s -> s.getGradeId().equals(gradeId))
                .map(ScoreDTO::getCourseId)
                .collect(Collectors.toSet());
    }

    @Override
    public Set<Integer> getClassScoreCourseList(Integer classId,Integer term){
        return scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                .eq(Score::getTerm,term)
        )
                .stream()
                .map(this::toDTO)
                .filter(s -> s.getClassId().equals(classId))
                .map(ScoreDTO::getCourseId)
                .collect(Collectors.toSet());
    }

    @Override
    public List<GradeScore> findGradeScoreList(Integer majorId, Integer courseId, Integer account){
        Set<Integer> gradeIdSet=gradeService.findGradeIdsByMajorId(majorId);
        List<GradeScore> result=new LinkedList<>();
        for (int g:gradeIdSet){
            GradeScore goal=new GradeScore();
            List<ScoreDTO> sc= scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                    .eq(Score::getCourseId,courseId)
            )
                    .stream()
                    .map(this::toDTO)
                    .filter(scoreDTO -> scoreDTO.getGradeId().equals(g))
                    .collect(Collectors.toList());
            goal.setGrade(gradeService.findNumById(g).orElse(0));
            //这里感觉不需要，填完数据再看
            int num=sc.stream().map(ScoreDTO::getStudentId).collect(Collectors.toSet()).size();
            goal.setTotalNum(num);
            List<Double> scoreList=sc.stream().map(ScoreDTO::getScore).collect(Collectors.toList());
            List<Double> normalScoreList=sc.stream().filter(s -> !studentService.findIsSpecial(s.getStudentId())).map(ScoreDTO::getScore).collect(Collectors.toList());
            List<Double> specialScoreList=sc.stream().filter(s -> studentService.findIsSpecial(s.getStudentId())).map(ScoreDTO::getScore).collect(Collectors.toList());
            List<Double> gpaList=sc.stream().map(ScoreDTO::getGradePoint).collect(Collectors.toList());
            double sum=scoreList.stream().mapToDouble(Double::doubleValue).sum();
            goal.setAverage(sum/sc.size());
            //挂科人数
            QuotaDTO quota=quotaService.findQuota(account);
            Integer failNum= (int) normalScoreList.stream().filter(x -> x < quota.getCutOff()).count()+ (int) specialScoreList.stream().filter(x -> x < quota.getSpecialCutoff()).count();
            goal.setFailNum(failNum);
            Double ab=quota.getSubjectAB();
            double abNum= (int) scoreList.stream().filter(x -> x >= ab).count();
            goal.setSubjectAB(abNum/num);
            goal.setPass(((double) num -failNum.doubleValue())/ (double) num);
            Double gradeAB=quota.getGradeAB();
            int gradeAbNum= (int) gpaList.stream().filter(x -> x >= gradeAB).count();
            goal.setGradeAB((double) gradeAbNum / (double) num);
            result.add(goal);
        }
        return result;
    }

    @Override
    public List<CounselorScore> findCounselorScoreList(Integer gradeId, Integer term,Integer account,Integer courseId){
        List<ClassDTO> classList=classService.findClassListByGradeId(gradeId);
        List<CounselorScore> result=new LinkedList<>();
        List<Double> gradeScore=findGradePointByGradeIdAndTerm(gradeId,term);
        QuotaDTO quota=quotaService.findQuota(account);
        for (int i=0;i<classList.size();i++){
            Integer classId=classList.get(i).getClassId();
            //班级名
            Integer classNum=classList.get(i).getName();
            if (courseId==0){
                List<Double> termScore=findGradePointByClassIdAndTerm(classId,term);
                double gradeABNum= (int) termScore.stream().filter(x -> x >= quota.getGradeAB()).count();
                Double gradePointAB=gradeABNum/termScore.size();
                CounselorScore counselorScore=new CounselorScore(classNum,null,gradePointAB,null,null,null,null);
                result.add(counselorScore);
            }else {
                List<ScoreDTO> scoreList=findListByTermAndClassIdAndCourseId(term,classId,courseId);
                Set<Integer> studentIdList=scoreList.stream().map(ScoreDTO::getStudentId).collect(Collectors.toSet());
                List<Double> percentList=scoreList.stream().map(ScoreDTO::getScore).collect(Collectors.toList());
                //总人数
                Integer totalNum=studentIdList.size();
                //班级优秀率
                List<Double> classScore=findGradePointByClassIdAndTerm(classId,term);
                int index=(int)(gradeScore.size()*quota.getClassAB());
                Double classTarget=gradeScore.get(index);
                double classABNum= (int) classScore.stream().filter(x -> x >= classTarget).count();
                Double classPointAB=classABNum/classScore.size();
                //平均分
                double sum=percentList.stream().mapToDouble(Double::doubleValue).sum();
                Double average=sum/scoreList.size();
                //挂科人数
                Integer failNum=scoreList.stream().filter(
                        scoreDTO -> ((!studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getCutOff()) || (studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getSpecialCutoff()))
                ).map(ScoreDTO::getStudentId).collect(Collectors.toSet()).size();
                //科目优秀率
                double subjectABNum= (int) percentList.stream().filter(x -> x >= quota.getSubjectAB()).count();
                Double subjectAB=subjectABNum/scoreList.size();
                //及格率
                double passNum= (int) percentList.stream().filter(x -> x >= quota.getCutOff()).count();
                Double pass=passNum/scoreList.size();
                CounselorScore counselorScore=new CounselorScore(classNum,totalNum,classPointAB,average,failNum,subjectAB,pass);
                result.add(counselorScore);
            }
        }
        if (courseId==0){
            return result;
        }
        //年级总人数
        Integer totalNum=result.stream().map(CounselorScore::getTotalNum).mapToInt(Integer::intValue).sum();
        Integer failNum=result.stream().map(CounselorScore::getFailNum).mapToInt(Integer::intValue).sum();
        double pass=(double) (totalNum-failNum)/(double) totalNum;
        Double average=result.stream().map(CounselorScore::getAverage).mapToDouble(Double::doubleValue).sum()/result.size();
        Double subjectAB=result.stream().map(CounselorScore::getSubjectAB).mapToDouble(Double::doubleValue).sum()/result.size();
        //年级优秀率
        double gradeABNum= (int) gradeScore.stream().filter(x -> x >= quota.getGradeAB()).count();
        Double gradePointAB=gradeABNum/gradeScore.size();
        CounselorScore score=new CounselorScore(99,totalNum,gradePointAB,average,failNum,subjectAB,pass);
        result.add(score);
        return result;
    }

    @Override
    public BaseScore findBaseScore(Integer gradeId, Integer term,Integer account){

        Integer lastTerm=term%2==0?term-1:term-99;
        List<ScoreDTO> scoreList=scoreMapper
                .selectList(Wrappers.lambdaQuery(Score.class)
                        .eq(Score::getTerm,term))
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO -> scoreDTO.getGradeId().equals(gradeId))
                .collect(Collectors.toList());
        QuotaDTO quota=quotaService.findQuota(account);
        Set<Integer> studentIdList=scoreList.stream().map(ScoreDTO::getStudentId).collect(Collectors.toSet());
        //总人数
        Integer totalNum=studentIdList.size();

        List<Double> gradeScore=findGradePointByGradeIdAndTerm(gradeId,term);
        List<Double> percentList=scoreList.stream().map(ScoreDTO::getScore).collect(Collectors.toList());

        //上学期内容
        List<ScoreDTO> scoreLastList=scoreMapper
                .selectList(Wrappers.lambdaQuery(Score.class)
                        .eq(Score::getTerm,lastTerm))
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO -> scoreDTO.getGradeId().equals(gradeId))
                .collect(Collectors.toList());
        List<Double> gradePointLastList=scoreLastList.stream().map(scoreDTO -> findPersonGradePoint(scoreDTO.getStudentId(),term)).collect(Collectors.toList());
        List<Double> percentLastList=scoreLastList.stream().map(ScoreDTO::getScore).collect(Collectors.toList());

        //一些参数
        Double gradeABChange;
        double failChange;
        Double passChange;

        //绩点优秀率
        double gradeABNum= (int) gradeScore.stream().filter(x -> x >= quota.getGradeAB()).count();
        Double gradePointAB=gradeABNum/gradeScore.size();
        //挂科人数
        Integer failNum=scoreList.stream().filter(
                scoreDTO -> (!studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getCutOff()) || (studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getSpecialCutoff())
        ).map(ScoreDTO::getStudentId).collect(Collectors.toSet()).size();
        //及格率
        double passNum= (int) percentList.stream().filter(x -> x >= quota.getCutOff()).count();
        Double pass=passNum/scoreList.size();

        if (scoreLastList.size()!=0){
            //绩点优秀率变化
            double gradeAB= (int) gradePointLastList.stream().filter(x -> x >= quota.getGradeAB()).count();
            gradeABChange=gradePointAB-gradeAB/scoreList.size();
            //挂科率变化
            Integer failLastNum=scoreLastList.stream().filter(
                    scoreDTO -> (!studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getCutOff()) || (studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getSpecialCutoff())
            ).map(ScoreDTO::getStudentId).collect(Collectors.toSet()).size();
            //及格率变化
            double passLast=(int) percentLastList.stream().filter(x -> x >= quota.getCutOff()).count();
            passChange=pass-passLast/scoreList.size();
            failChange=failNum-failLastNum/totalNum;
        }else {
            gradeABChange=0.0;
            failChange=0.0;
            passChange=0.0;
        }
        return new BaseScore(totalNum,gradePointAB,gradeABChange,failNum,failChange,pass,passChange);
    }

    @Override
    public ScoreComparison findScoreComparison(Integer account, Integer term, Integer classId){
        QuotaDTO quota=quotaService.findQuota(account);
        Integer gradeId=classService.findGradeIdByClassId(classId).orElse(0);
        List<Double> gradeScore=findGradePointByGradeIdAndTerm(gradeId,term);
        List<Double> classScore=findGradePointByClassIdAndTerm(classId,term);

        //年级成绩
        List<ScoreDTO> scoreGradeList=scoreMapper
                .selectList(Wrappers.lambdaQuery(Score.class)
                        .eq(Score::getTerm,term))
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO -> scoreDTO.getGradeId().equals(gradeId))
                .collect(Collectors.toList());
        double gradeFail=scoreGradeList.stream().filter(
                scoreDTO -> (!studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getCutOff()) || (studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getSpecialCutoff())
        ).map(ScoreDTO::getStudentId).collect(Collectors.toSet()).size();
        //班级成绩
        List<ScoreDTO> scoreClassList=scoreMapper
                .selectList(Wrappers.lambdaQuery(Score.class)
                        .eq(Score::getTerm,term))
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO -> scoreDTO.getClassId().equals(classId))
                .collect(Collectors.toList());
        double classFail=scoreClassList.stream().filter(
                scoreDTO -> (studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getCutOff()) || (!studentService.findIsSpecial(scoreDTO.getStudentId()) && scoreDTO.getScore()<quota.getSpecialCutoff())
        ).map(ScoreDTO::getStudentId).collect(Collectors.toSet()).size();

        int index=(int)(gradeScore.size()*quota.getClassAB());
        Double classTarget=gradeScore.get(index);
        Double gradeTarget=quota.getGradeAB();
        //年级优秀率
        double gradeABNum= (int) gradeScore.stream().filter(x -> x >= gradeTarget).count();
        Double gradePointAB=gradeABNum/gradeScore.size();
        //班级优秀率
        double classABNum= (int) classScore.stream().filter(x -> x >= classTarget).count();
        Double classPointAB=classABNum/classScore.size();
        //年级及格率
        Double gradePass=1-gradeFail/gradeScore.size();
        //班级及格率
        Double classPass=1-classFail/classScore.size();
        return new ScoreComparison(gradePointAB,classPointAB,gradePass,classPass);
    }

    @Override
    public List<Average> findSubjectAverage(Integer gradeId, Integer term){
        Set<Integer> courseIdSet=getCounselorCourseIdList(gradeId,term);
        List<ScoreDTO> scoreList=findListByGradeIdAndTerm(gradeId,term);
        List<Integer> courseIdList= new ArrayList<>(courseIdSet);
        List<Average> result=new LinkedList<>();
        for (int i=0;i<courseIdList.size();i++){
            Integer courseId=courseIdList.get(i);
            List<Double> score=scoreList.stream()
                    .filter(scoreDTO -> scoreDTO.getCourseId().equals(courseId))
                    .map(ScoreDTO::getScore)
                    .collect(Collectors.toList());
            Double value=score.stream().mapToDouble(Double::doubleValue).sum()/score.size();
            String courseName=courseService.findNameById(courseId).orElse(null);
            Average average=new Average(courseId,courseName,value);
            result.add(average);
        }
        return result;
    }

    @Override
    public List<Average> getClassAverage(Integer classId, Integer term){
        Set<Integer> courseIdSet=getClassScoreCourseList(classId,term);
        List<ScoreDTO> scoreList=findListByClassIdAndTerm(classId,term);
        List<Average> result=new LinkedList<>();
        List<Integer> courseList= new ArrayList<>(courseIdSet);
        for (int i=0;i<courseList.size();i++){
            Integer courseId=courseList.get(i);
            List<Double> score=scoreList.stream()
                    .filter(scoreDTO -> scoreDTO.getCourseId().equals(courseId))
                    .map(ScoreDTO::getScore)
                    .collect(Collectors.toList());
            Double value=score.stream().mapToDouble(Double::doubleValue).sum()/score.size();
            String courseName=courseService.findNameById(courseId).orElse(null);
            Average average=new Average(courseId,courseName,value);
            result.add(average);
        }
        return result;
    }

    @Override
    public List<ClassScore> getClassScore(Integer classId, Integer term, Set<Integer> courseIdList){
        List<StudentDTO> students=studentService.findStudentListByClassId(classId);
        List<ClassScore> classScore=new ArrayList<>();
        for (int i=0;i<students.size();i++){
            StudentDTO student=students.get(i);
            Integer studentId=student.getStudentId();
            String name=student.getName();
            List<SubjectScore> returnScore=new ArrayList<>();

            List<ScoreDTO> scoreList=findListByTermAndStudentId(studentId,term);
            Double gradePoint=findPersonGradePoint(studentId,term);
            List<Integer> course= new ArrayList<>(courseIdList);
            for (int j=0;j<course.size();j++){
                Integer courseId=course.get(j);
                if (scoreMapper.selectCount(Wrappers.lambdaQuery(Score.class).eq(Score::getCourseId,courseId))>0){
                    ScoreDTO one=scoreList
                            .stream()
                            .filter(scoreDTO -> scoreDTO.getCourseId().equals(courseId))
                            .findFirst()
                            .orElse(null);
                    if (one!=null){
                        Double score=one.getScore();
                        Double makeUp=one.getMakeUp();
                        returnScore.add(new SubjectScore(courseId,score,makeUp));
                    }
                }
            }
            ClassScore result=new ClassScore(studentId,name,gradePoint,returnScore);
            classScore.add(result);
        }
        return classScore;
    }


    @Override
    public List<ScoreDTO> findListByTermAndClassIdAndCourseId(Integer term,Integer classId,Integer courseId){
        return scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                .eq(Score::getTerm,term)
                .eq(Score::getCourseId,courseId)
        )
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO->scoreDTO.getClassId().equals(classId))
                .collect(Collectors.toList());
    }

    @Override
    public List<ScoreDTO> findListByGradeIdAndTerm(Integer gradeId,Integer term){
        return scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                .eq(Score::getTerm,term)
        )
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO->scoreDTO.getGradeId().equals(gradeId))
                .collect(Collectors.toList());
    }


    public List<ScoreDTO> findListByClassIdAndTerm(Integer classId,Integer term){
        return scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                .eq(Score::getTerm,term)
        )
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO->scoreDTO.getClassId().equals(classId))
                .collect(Collectors.toList());
    }

    public List<ScoreDTO> findListByTermAndStudentId(Integer studentId,Integer term){
        return scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                .eq(Score::getTerm,term)
                .eq(Score::getStudentId,studentId)
        )
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<Double> findListByGradeIdAndTermAndCourseId(Integer gradeId,Integer term,Integer courseId){
        return scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                .eq(Score::getTerm,term)
        )
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO->scoreDTO.getGradeId().equals(gradeId)&&scoreDTO.getCourseId().equals(courseId))
                .map(ScoreDTO::getGradePoint)
                .collect(Collectors.toList());
    }

    public List<Double> findGradePointByClassIdAndTerm(Integer classId,Integer term){
        List<ScoreDTO> scoreDTOS=scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                .eq(Score::getTerm,term)
        )
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO->scoreDTO.getClassId().equals(classId))
                .collect(Collectors.toList());
        Set<Integer> studentIdSet=scoreDTOS
                .stream()
                .map(ScoreDTO::getStudentId)
                .collect(Collectors.toSet()
                );
        List<Integer> studentIdList= new ArrayList<>(studentIdSet);
        List<Double> result=new ArrayList<>();
        for (int i=0;i<studentIdList.size();i++){
            int sign=i;
            Double termGradePoint=scoreDTOS.stream()
                    .filter(scoreDTO -> scoreDTO.getStudentId().equals(studentIdList.get(sign)))
                    .map(ScoreDTO::getTermGradePoint)
                    .mapToDouble(Double::doubleValue).sum();
            Double creditSum=scoreDTOS.stream()
                    .filter(scoreDTO -> scoreDTO.getStudentId().equals(studentIdList.get(sign)))
                    .map(ScoreDTO::getCredit)
                    .mapToDouble(Double::doubleValue).sum();
            result.add(termGradePoint/creditSum);
        }
        return result;
    }

    public List<Double> findGradePointByGradeIdAndTerm(Integer gradeId,Integer term){
        List<ScoreDTO> scoreDTOS=scoreMapper.selectList(Wrappers.lambdaQuery(Score.class)
                .eq(Score::getTerm,term)
        )
                .stream()
                .map(this::toDTO)
                .filter(scoreDTO->scoreDTO.getGradeId().equals(gradeId))
                .collect(Collectors.toList());
        Set<Integer> studentIdSet=scoreDTOS
                .stream()
                .map(ScoreDTO::getStudentId)
                .collect(Collectors.toSet()
                );
        List<Integer> studentIdList= new ArrayList<>(studentIdSet);
        List<Double> result=new ArrayList<>();
        for (int i=0;i<studentIdList.size();i++){
            int sign=i;
            Double termGradePoint=scoreDTOS.stream()
                    .filter(scoreDTO -> scoreDTO.getStudentId().equals(studentIdList.get(sign)))
                    .map(ScoreDTO::getTermGradePoint)
                    .mapToDouble(Double::doubleValue).sum();
            Double creditSum=scoreDTOS.stream()
                    .filter(scoreDTO -> scoreDTO.getStudentId().equals(studentIdList.get(sign)))
                    .map(ScoreDTO::getCredit)
                    .mapToDouble(Double::doubleValue).sum();
            result.add(termGradePoint/creditSum);
        }
        return result;
    }

    @Override
    public List<Integer> findPieChart(Double extent,Integer gradeId,Integer term){
        int length=(int)(4/extent);
        List<Integer> result=new ArrayList<>();
        List<Double> scoreList=findGradePointByGradeIdAndTerm(gradeId,term);
        for(int i=0;i<length;i++){
            int times=i;
            result.add((int) scoreList
                    .stream()
                    .filter(s -> s >= extent * times && s < extent * (times + 1)).count()
            );
        }
        return result;
    }

    @Override
    public List<Integer> findClassPieChart(Double extent,Integer classId,Integer term){
        int length=(int)(4/extent);
        System.out.println(length);
        List<Integer> result=new ArrayList<>();
        List<Double> scoreList=findGradePointByClassIdAndTerm(classId,term);
        System.out.println(scoreList);
        for(int i=0;i<length;i++){
            int times=i;
            result.add((int) scoreList
                    .stream()
                    .filter(s -> s >= extent * times && s < extent * (times + 1)).count()
            );
        }
        return result;
    }

    @Override
    public void insertList(List<List<Object>> scoreList,Integer fileId){
        //TODO 关于补考怎么弄
        for (int i=0;i<scoreList.size();i++){

            int index=i;
            String percentCore=scoreList.get(index).get(3).toString();
            double percentCoreValue;
            switch (percentCore) {
                //免修成绩是80吗
                case "免修":
                case "良好":
                    percentCoreValue = 80.0;
                    break;
                case "中等":
                    percentCoreValue = 70.0;
                    break;
                case "缺考":
                case "不及格":
                    percentCoreValue = 0.0;
                    break;
                case "优秀":
                    percentCoreValue = 90.0;
                    break;
                case "及格":
                case "合格":
                    percentCoreValue = 60.0;
                    break;
                default:
                    percentCoreValue = Double.parseDouble(percentCore);
                    break;
            }
            String type=scoreList.get(index).get(5).toString();
            Score score=new Score(){
                {
                    setTerm(Integer.parseInt(scoreList.get(index).get(0).toString()));
                    setStudentId(Integer.parseInt(scoreList.get(index).get(1).toString()));
                    setCourseId(courseService.findIdByName(scoreList.get(index).get(2).toString()).orElse(0));
                    setType(type);
                    setFileId(fileId);
                }
            };
            Score makeup=scoreMapper
                    .selectOne(Wrappers.lambdaQuery(Score.class)
                            .eq(Score::getCourseId,score.getCourseId())
                            .eq(Score::getStudentId,score.getStudentId())
                            .eq(Score::getTerm,score.getTerm())
                    );
            if (type.equals("正常考考试补考")){
                if (makeup==null){
                    score.setMakeUp(percentCoreValue);
                    scoreMapper.insert(score);
                }else {
                    makeup.setMakeUp(percentCoreValue);
                    scoreMapper.update(makeup, Wrappers.lambdaUpdate(Score.class)
                            .eq(Score::getScoreId,makeup.getScoreId()));
                }
            }else if (type.matches("第1次重修.*")){
                score.setScore(percentCoreValue);
                if (percentCoreValue>=85){
                    score.setGradePoint(3.0);
                }else if (percentCoreValue>=75){
                    score.setGradePoint(2.0);
                }else if (percentCoreValue>=60){
                    score.setGradePoint(1.0);
                }else {
                    score.setGradePoint(0.0);
                }
                if (makeup==null){
                    scoreMapper.insert(score);
                }else {
                    score.setScoreId(makeup.getScoreId());
                    scoreMapper.update(makeup, Wrappers.lambdaUpdate(Score.class)
                            .eq(Score::getScoreId,makeup.getScoreId()));
                }
            }else if (type.matches("第[2-9]次重修.*")){
                score.setScore(percentCoreValue);
                score.setGradePoint(1.0);
                if (makeup==null){
                    scoreMapper.insert(score);
                }else {
                    score.setScoreId(makeup.getScoreId());
                    scoreMapper.update(makeup, Wrappers.lambdaUpdate(Score.class)
                            .eq(Score::getScoreId,makeup.getScoreId()));
                }
            } else {
                //正常情况
                score.setScore(percentCoreValue);
                score.setGradePoint(Double.parseDouble(scoreList.get(index).get(4).toString()));
                try {
                    scoreMapper.insert(score);
                } catch (DuplicateKeyException e) {
                    return;
                }
            }

        }
    }

    private Double findPersonGradePoint(Integer studentId,Integer term){
        List<ScoreDTO> scoreList=findListByTermAndStudentId(studentId,term);
        Double termGradePoint=scoreList.stream()
                .map(ScoreDTO::getTermGradePoint)
                .mapToDouble(Double::doubleValue).sum();
        Double creditSum=scoreList.stream()
                .map(ScoreDTO::getCredit)
                .mapToDouble(Double::doubleValue).sum();
        return termGradePoint/creditSum;
    }

    @Override
    public List<Integer> findClassRankAndGradeRank(Integer studentId,Integer term){
        StudentDTO studentDTO=studentService.findByStudentId(studentId).orElse(null);
        //个人学期绩点
        Double gradePoint=findPersonGradePoint(studentId,term);
        //班级成绩列表
        assert studentDTO != null;
        List<Double> classScore=findGradePointByClassIdAndTerm(studentDTO.getClassId(), term)
                .stream()
                .distinct()
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());
        Integer classRank=classScore.indexOf(gradePoint)+1;
        //年级成绩列表
        List<Double> gradeScore=new HashSet<>(findGradePointByGradeIdAndTerm(studentDTO.getGradeId(), term))
                .stream()
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());
        Integer gradeRank=gradeScore.indexOf(gradePoint)+1;
        return Arrays.asList(classRank, gradeRank);
    }

    @Override
    public List<TermGrade> findGradeListByStudentIdAndTerm(Integer studentId,Integer term){
        List<TermGrade> gradeList=new ArrayList<>();
        for (int i=0;i<5;i++){
            Double gradePoint=findPersonGradePoint(studentId,term);
            gradeList.add(new TermGrade(term,gradePoint));
            if (term%2==0){
                term=term-1;
            }else {
                term=term-99;
            }
        }
        return gradeList;
    }

    private ScoreDTO toDTO(Score score) {
        ScoreDTO sc = new ScoreDTO();
        sc.setScoreId(score.getScoreId());
        sc.setScore(score.getScore());
        sc.setCourseId(score.getCourseId());
        sc.setType(score.getType());
        sc.setFileId(score.getFileId());
        sc.setGradePoint(score.getGradePoint());
        sc.setMakeUp(score.getMakeUp());
        sc.setStudentId(score.getStudentId());
        sc.setClassId(studentService.findClassIdByStudentNum(score.getStudentId()).orElse(0));
        sc.setMajorId(studentService.findMajorId(score.getStudentId()).orElse(0));
        sc.setGradeId(classService.findGradeIdByClassId(sc.getClassId()).orElse(0));
        sc.setCredit(courseService.findCreditById(sc.getCourseId()).orElse(0.0));
        sc.setTerm(score.getTerm());
        return sc;
    }

}
