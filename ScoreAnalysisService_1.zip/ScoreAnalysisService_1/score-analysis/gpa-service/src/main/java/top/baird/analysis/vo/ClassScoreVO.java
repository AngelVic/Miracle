package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import top.baird.analysis.model.pojo.SubjectScore;

import java.util.List;

@ApiModel
@AllArgsConstructor
public class ClassScoreVO {

    @ApiModelProperty("学号")
    public final Integer studentId;

    @ApiModelProperty("姓名")
    public final String name;

    @ApiModelProperty("学期绩点")
    public final Double gradePoint;

    @ApiModelProperty(value = "成绩列表")
    public final List<SubjectScore> scoreList;

}
