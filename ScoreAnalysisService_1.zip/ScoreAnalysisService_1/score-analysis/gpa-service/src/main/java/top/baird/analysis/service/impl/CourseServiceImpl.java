package top.baird.analysis.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.CourseMapper;
import top.baird.analysis.model.dto.CourseDTO;
import top.baird.analysis.po.Course;
import top.baird.analysis.service.gpa.CourseService;
import top.baird.analysis.service.gpa.ScoreService;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CourseServiceImpl implements CourseService {

    @Resource
    ScoreService scoreService;

    @Resource
    CourseMapper courseMapper;

    @Override
    public List<CourseDTO> getCourseList(Integer majorId){
        Set<Integer> idList=scoreService.getCourseIdList(majorId);
        return courseMapper.selectBatchIds(idList)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<CourseDTO> getCounselorCourseList(Integer gradeId,Integer term){
        Set<Integer> idList=scoreService.getCounselorCourseIdList(gradeId,term);
        return courseMapper.selectBatchIds(idList)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<CourseDTO> getClassScoreCourseList(Integer classId,Integer term){
        Set<Integer> idList=scoreService.getClassScoreCourseList(classId,term);
        return courseMapper.selectBatchIds(idList)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public boolean exists(String courseName){
        return courseName != null &&
                courseMapper.selectCount(Wrappers.lambdaQuery(Course.class)
                        .eq(Course::getName, courseName)
                ) > 0;
    }

    @Override
    public Optional<Integer> findIdByName(String courseName){
        return Optional.ofNullable(courseMapper.selectOne(Wrappers.lambdaQuery(Course.class)
                        .eq(Course::getName,courseName)
                ).getCourseId()
        );
    }

    @Override
    public Optional<String> findNameById(Integer courseId){
        return Optional.ofNullable(courseMapper.selectById(courseId).getName());
    }

    @Override
    public Optional<Double> findCreditById(Integer courseId){
        return Optional.ofNullable(courseMapper.selectOne(Wrappers.lambdaQuery(Course.class)
                        .eq(Course::getCourseId,courseId)
                ).getCredit()
        );
    }



    @Override
    public void insertList(List<List<Object>> courseList){
        for (int i=0;i<courseList.size();i++){
            int index=i;
            String courseName=courseList.get(index).get(0).toString().trim();
            if (!exists(courseName)){
                Course course=new Course(){
                    {
                        setName(courseName);
                        setCredit(Double.parseDouble(courseList.get(index).get(1).toString()));
                        setType(courseList.get(index).get(2).toString());
                    }
                };
                try {
                    courseMapper.insert(course);
                } catch (DuplicateKeyException e) {
                    return;
                }
            }
        }
    }

    private CourseDTO toDTO(Course course) {
        CourseDTO cs = new CourseDTO();
        cs.setCourseId(course.getCourseId());
        cs.setCredit(course.getCredit());
        cs.setType(course.getType());
        cs.setName(course.getName());
        return cs;
    }


}
