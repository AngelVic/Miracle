package top.baird.analysis.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.stereotype.Service;
import top.baird.analysis.mapper.QuotaMapper;
import top.baird.analysis.model.dto.QuotaDTO;
import top.baird.analysis.po.Quota;
import top.baird.analysis.service.gpa.QuotaService;

import javax.annotation.Resource;

@Service
public class QuotaServiceImpl implements QuotaService {

    @Resource
    QuotaMapper quotaMapper;

    @Override
    public QuotaDTO findQuota(Integer account){
        return toDTO(quotaMapper.selectOne(Wrappers.lambdaQuery(Quota.class)
                .eq(Quota::getQuotaId,account)));
    }

    @Override
    public boolean exists(Integer account){
        return account != null &&
                quotaMapper.selectCount(Wrappers.lambdaQuery(Quota.class)
                        .eq(Quota::getQuotaId, account)
                ) > 0;
    }

    @Override
    public void createDefault(Integer account){
        Quota quota = new Quota() {{
            setClassAB(0.5);
            setCutOff(60.0);
            setSpecialCutoff(40.0);
            setGradeAB(3.0);
            setSubjectAB(85.0);
            setQuotaId(account);
        }};
        quotaMapper.insert(quota);
    }

    @Override
    public void update(QuotaDTO quotaDTO){
        Quota quota = new Quota() {{
            setQuotaId(quotaDTO.getQuotaId());
            setClassAB(quotaDTO.getClassAB());
            setCutOff(quotaDTO.getCutOff());
            setSpecialCutoff(quotaDTO.getSpecialCutoff());
            setGradeAB(quotaDTO.getGradeAB());
            setSubjectAB(quotaDTO.getSubjectAB());
        }};
        quotaMapper.update(quota, Wrappers.lambdaQuery(Quota.class)
                .eq(Quota::getQuotaId, quotaDTO.getQuotaId())
        );
    }

    private QuotaDTO toDTO(Quota quota) {
        QuotaDTO q = new QuotaDTO();
        q.setQuotaId(quota.getQuotaId());
        q.setClassAB(quota.getClassAB());
        q.setCutOff(quota.getCutOff());
        q.setGradeAB(quota.getGradeAB());
        q.setSubjectAB(quota.getSubjectAB());
        q.setIsAdmin(quota.getIsAdmin());
        q.setSpecialCutoff(quota.getSpecialCutoff());
        return q;
    }

}
