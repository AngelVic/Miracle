package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class BaseVO {

    @ApiModelProperty("总人数")
    public final Integer totalNum;

    @ApiModelProperty("绩点优秀率")
    public Double gradePointAB;

    @ApiModelProperty("优秀率变化")
    public Double ABChange;

    @ApiModelProperty("挂科人数")
    public Integer failNum;

    @ApiModelProperty("挂科变化")
    public Double failChange;

    @ApiModelProperty("及格率")
    public Double pass;

    @ApiModelProperty("及格率变化")
    public Double passChange;

}
