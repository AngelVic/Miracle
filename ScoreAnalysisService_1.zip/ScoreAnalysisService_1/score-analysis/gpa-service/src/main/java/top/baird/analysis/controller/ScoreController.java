package top.baird.analysis.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.baird.analysis.ex.CustomParamException;
import top.baird.analysis.model.Result;
import top.baird.analysis.service.classes.ClassService;
import top.baird.analysis.service.gpa.CourseService;
import top.baird.analysis.service.gpa.ScoreService;
import top.baird.analysis.vo.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/score")
public class ScoreController {

    @Resource
    ScoreService scoreService;

    @Resource
    ClassService classService;

    @GetMapping("/admin")
    @ApiOperation(value = "管理员获取年级成绩列表",tags = "管理员-年级成绩对比")
    public Result<List<GradeScoreVO>> getGradeScoreList(@ApiParam("专业id") Integer majorId, @ApiParam("科目id") Integer courseId, @ApiParam("账号")Integer account){
        return Result.success(scoreService.findGradeScoreList(majorId,courseId,account)
                .stream()
                .map(gs -> new GradeScoreVO(
                        gs.getGrade(),
                        gs.getTotalNum(),
                        gs.getGradeAB(),
                        gs.getAverage(),
                        gs.getFailNum(),
                        gs.getSubjectAB(),
                        gs.getPass()
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/base")
    @ApiOperation(value = "年级成绩基础数据",tags = "辅导员-年级成绩")
    public Result<BaseVO> getBaseScore( @ApiParam("年级专业id") Integer gradeId, @ApiParam("学期")Integer term,@ApiParam("辅导员账号")Integer account){
        return Result.success(Optional.of(scoreService.findBaseScore(gradeId,term,account))
                .map(baseScore -> new BaseVO(
                        baseScore.getTotalNum(),
                        baseScore.getGradePointAB(),
                        baseScore.getABChange(),
                        baseScore.getFailNum(),
                        baseScore.getFailChange(),
                        baseScore.getPass(),
                        baseScore.getPassChange())
                ).orElse(null)
        );
    }

    @GetMapping("/counselor")
    @ApiOperation(value = "辅导员获取年级-班级成绩对比列表",tags = "辅导员-年级成绩")
    public Result<List<CounselorScoreVO>> getCounselorScoreList( @ApiParam("年级专业id") Integer gradeId, @ApiParam("学期")Integer term,@ApiParam("辅导员账号")Integer account,@ApiParam("科目id")Integer courseId){
        return Result.success(scoreService.findCounselorScoreList(gradeId,term,account,courseId)
                .stream()
                .map(cs -> new CounselorScoreVO(
                        cs.getClassNum(),
                        cs.getTotalNum(),
                        cs.getGradePointAB(),
                        cs.getAverage(),
                        cs.getFailNum(),
                        cs.getSubjectAB(),
                        cs.getPass()
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/grade/average")
    @ApiOperation(value = "获取年级成绩-科目优势雷达图",tags = "辅导员-年级成绩")
    public Result<List<AverageVO>> getSubjectAverage(@ApiParam("年级专业id") Integer gradeId, @ApiParam("学期")Integer term){
        return Result.success(scoreService.findSubjectAverage(gradeId,term)
                .stream()
                .map(average -> new AverageVO(
                        average.courseId,
                        average.courseName,
                        average.average
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/grade/pieChart")
    @ApiOperation(value = "年级成绩分布饼状图",tags = "辅导员-年级成绩")
    public Result<List<Integer>> getPieChart(@ApiParam("区间") Double extent,@ApiParam("年级专业id") Integer gradeId,@ApiParam("学期")Integer term){
        return Result.success(scoreService.findPieChart(extent,gradeId,term));
    }

//    @GetMapping("/student")
//    @ApiOperation(value = "获取学生个人成绩",tags = "学生信息")
//    public Result<StudentScore> getStudentScore(@ApiParam("学号") Integer studentId){
//
//    }

    @GetMapping("/class")
    @ApiOperation(value = "获取班级成绩列表",tags = "辅导员-班级成绩")
    public Result<List<ClassScoreVO>> getClassScore(@ApiParam("班级id") Integer classId, @ApiParam("学期")Integer term){
        if (!classService.exists(classId)){
            throw CustomParamException.of("班级 {} 不存在",classId);
        }
        Set<Integer> courseIdList=scoreService.getClassScoreCourseList(classId,term);
        return Result.success(scoreService.getClassScore(classId,term,courseIdList)
                .stream()
                .map(classScore -> new ClassScoreVO(
                        classScore.getStudentId(),
                        classScore.getName(),
                        classScore.getGradePoint(),
                        classScore.getScoreList()
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/class/average")
    @ApiOperation(value = "获取班级科目优势分析雷达图",tags = "辅导员-班级成绩")
    public Result<List<AverageVO>> getClassAverage(@ApiParam("班级id") Integer classId, @ApiParam("学期")Integer term) {
        return Result.success(scoreService.getClassAverage(classId,term)
                .stream()
                .map(average -> new AverageVO(
                        average.courseId,
                        average.courseName,
                        average.average
                ))
                .collect(Collectors.toList())
        );
    }

    @GetMapping("/class/pieChart")
    @ApiOperation(value = "班级成绩分布饼状图",tags = "辅导员-班级成绩")
    public Result<List<Integer>> getClassPieChart(@ApiParam("区间") Double extent,@ApiParam("班级id") Integer classId,@ApiParam("学期")Integer term){
        return Result.success(scoreService.findClassPieChart(extent,classId,term));
    }

    @GetMapping("/class/comparison")
    @ApiOperation(value = "年级-班级对比",tags = "辅导员-班级成绩")
    public Result<ScoreComparisonVO> getScoreComparison(@ApiParam("辅导员账号")Integer account, @ApiParam("班级id") Integer classId, @ApiParam("学期")Integer term){
        return Result.success(
                Optional.ofNullable(scoreService.findScoreComparison(account,term,classId)
                )
                        .map(scoreComparison ->new ScoreComparisonVO(
                                scoreComparison.gradeAB,
                                scoreComparison.classAB,
                                scoreComparison.gradePass,
                                scoreComparison.classPass)
                        ).orElse(null)
        );
    }



}
