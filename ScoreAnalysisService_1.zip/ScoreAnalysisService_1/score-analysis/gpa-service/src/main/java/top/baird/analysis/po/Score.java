package top.baird.analysis.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import top.baird.analysis.model.enums.ScoreType;

@Data
public class Score {
    @TableId(type = IdType.AUTO)
    private Integer scoreId;
    private Integer studentId;
    private Integer courseId;
    private Integer fileId;
    private Double gradePoint;
    private Double score;
    private String type;
    private Double makeUp;
    private Integer term;
}
