package top.baird.analysis.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;

@ApiModel
@AllArgsConstructor
public class AverageVO {

    @ApiModelProperty("课程id")
    public final Integer courseId;

    @ApiModelProperty("课程名")
    public final String courseName;

    @ApiModelProperty("平均值")
    public final Double average;
}
